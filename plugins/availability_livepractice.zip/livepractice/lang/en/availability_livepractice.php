<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Language strings for the live practice flights restriction.
 *
 * @package    availability_livepractice
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['description'] = 'Only allow access while live practice flight booking is switched on by a site administrator.';
$string['pluginname'] = 'Restriction by live practice flight availability';
$string['privacy:metadata'] = 'The live practice flights restriction plugin does not store any personal data.';
$string['requires_enabled'] = 'Live practice flight booking is currently open';
$string['requires_notenabled'] = 'Live practice flight booking is currently closed';
$string['setting_enabled'] = 'Allow booking live practice flights';
$string['setting_enabled_desc'] = 'When ticked, activities restricted by "Live practice flights" are available to students (subject to their other restrictions). When unticked, those activities are locked for all students on every course. Teachers and managers who can bypass restrictions are not affected.';
$string['event_booking_toggled'] = 'Live practice flight booking switched';
$string['livepractice:togglebooking'] = 'Open or close live practice flight booking';
$string['title'] = 'Live practice flight booking is open';
$string['toggle_close_button'] = 'Close booking';
$string['toggle_help'] = 'This switch applies to every course. Students are locked out of any activity that uses the "Live practice flight availability" restriction while booking is closed. Staff who can bypass restrictions are not affected.';
$string['toggle_link'] = 'Users with the "Open or close live practice flight booking" permission can also use {$a}.';
$string['toggle_open_button'] = 'Open booking';
$string['toggle_status_closed'] = 'Live practice flight booking is currently CLOSED.';
$string['toggle_status_open'] = 'Live practice flight booking is currently OPEN.';
$string['toggle_title'] = 'Live practice flight booking';
$string['toggle_updated_closed'] = 'Live practice flight booking is now closed.';
$string['toggle_updated_open'] = 'Live practice flight booking is now open.';
