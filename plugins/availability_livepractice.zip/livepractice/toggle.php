<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * One-button page for opening and closing live practice flight booking.
 *
 * @package    availability_livepractice
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../../config.php');
require_once(__DIR__ . '/lib.php');

require_login();
$context = context_system::instance();
require_capability('availability/livepractice:togglebooking', $context);

$url = new moodle_url('/availability/condition/livepractice/toggle.php');
$PAGE->set_url($url);
$PAGE->set_context($context);
$PAGE->set_pagelayout('standard');
$title = get_string('toggle_title', 'availability_livepractice');
$PAGE->set_title($title);
$PAGE->set_heading($title);

$newstate = optional_param('newstate', null, PARAM_INT);
if ($newstate !== null && data_submitted() && confirm_sesskey()) {
    $newstate = $newstate ? 1 : 0;
    $current = !empty(get_config('availability_livepractice', 'enabled'));
    if ((bool)$newstate !== $current) {
        set_config('enabled', $newstate, 'availability_livepractice');
        availability_livepractice_setting_updated();
    }
    redirect(
        $url,
        get_string($newstate ? 'toggle_updated_open' : 'toggle_updated_closed', 'availability_livepractice'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

$enabled = !empty(get_config('availability_livepractice', 'enabled'));

echo $OUTPUT->header();

echo $OUTPUT->notification(
    get_string($enabled ? 'toggle_status_open' : 'toggle_status_closed', 'availability_livepractice'),
    $enabled ? \core\output\notification::NOTIFY_SUCCESS : \core\output\notification::NOTIFY_WARNING
);

echo html_writer::tag('p', get_string('toggle_help', 'availability_livepractice'));

echo html_writer::start_tag('form', ['method' => 'post', 'action' => $url->out(false)]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'newstate', 'value' => $enabled ? 0 : 1]);
echo html_writer::tag(
    'button',
    get_string($enabled ? 'toggle_close_button' : 'toggle_open_button', 'availability_livepractice'),
    ['type' => 'submit', 'class' => 'btn ' . ($enabled ? 'btn-danger' : 'btn-primary')]
);
echo html_writer::end_tag('form');

echo $OUTPUT->footer();
