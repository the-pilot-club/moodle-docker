<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Library functions for the live practice flights restriction.
 *
 * @package    availability_livepractice
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Called whenever the flag changes, from the admin settings page or from the toggle page.
 * Clears the course modinfo cache so every course page re-evaluates the restriction
 * straight away, and records an audit event in the standard log.
 *
 * @param string $name Setting name (unused).
 */
function availability_livepractice_setting_updated($name = '') {
    rebuild_course_cache(0, true);

    \availability_livepractice\event\booking_toggled::create([
        'context' => context_system::instance(),
        'other' => ['enabled' => (int)!empty(get_config('availability_livepractice', 'enabled'))],
    ])->trigger();
}
