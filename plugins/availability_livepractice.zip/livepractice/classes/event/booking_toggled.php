<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace availability_livepractice\event;

/**
 * Event fired when live practice flight booking is opened or closed.
 *
 * @package    availability_livepractice
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class booking_toggled extends \core\event\base {

    /**
     * Initialise the event.
     */
    protected function init() {
        $this->data['crud'] = 'u';
        $this->data['edulevel'] = self::LEVEL_OTHER;
    }

    /**
     * Event name.
     *
     * @return string
     */
    public static function get_name() {
        return get_string('event_booking_toggled', 'availability_livepractice');
    }

    /**
     * Event description for the logs.
     *
     * @return string
     */
    public function get_description() {
        $state = !empty($this->other['enabled']) ? 'opened' : 'closed';
        return "The user with id '{$this->userid}' {$state} live practice flight booking.";
    }

    /**
     * Link to the toggle page.
     *
     * @return \moodle_url
     */
    public function get_url() {
        return new \moodle_url('/availability/condition/livepractice/toggle.php');
    }

    /**
     * Validate the event data.
     */
    protected function validate_data() {
        parent::validate_data();
        if (!isset($this->other['enabled'])) {
            throw new \coding_exception('The \'enabled\' value must be set in other.');
        }
    }

    /**
     * No other-field mappings are needed for restore.
     *
     * @return bool
     */
    public static function get_other_mapping() {
        return false;
    }
}
