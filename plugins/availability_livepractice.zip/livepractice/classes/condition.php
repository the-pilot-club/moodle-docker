<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace availability_livepractice;

/**
 * Condition that is met only while the site-wide "live practice flights" flag is on.
 *
 * @package    availability_livepractice
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class condition extends \core_availability\condition {

    /**
     * Constructor. The condition has no per-activity settings.
     *
     * @param \stdClass $structure Data structure from JSON decode.
     */
    public function __construct($structure) {
    }

    /**
     * Saves the condition to JSON structure.
     *
     * @return \stdClass
     */
    public function save() {
        return (object)['type' => 'livepractice'];
    }

    /**
     * Whether the site-wide flag is currently on.
     *
     * @return bool
     */
    protected static function flag_enabled(): bool {
        return !empty(get_config('availability_livepractice', 'enabled'));
    }

    /**
     * Checks whether the condition is met.
     *
     * @param bool $not Set true if we are inverting the condition.
     * @param \core_availability\info $info Item we're checking.
     * @param bool $grabthelot Performance hint, unused.
     * @param int $userid User ID to check.
     * @return bool True if available.
     */
    public function is_available($not, \core_availability\info $info, $grabthelot, $userid) {
        $allow = self::flag_enabled();
        if ($not) {
            $allow = !$allow;
        }
        return $allow;
    }

    /**
     * The result does not depend on the user, so it is the same for everyone.
     *
     * @param bool $not Set true if we are inverting the condition.
     * @return bool True if everyone passes this condition right now.
     */
    public function is_available_for_all($not = false) {
        return self::flag_enabled() !== (bool)$not;
    }

    /**
     * Gets the description shown to users when the condition is not met.
     *
     * @param bool $full Set true if this is the 'full information' view.
     * @param bool $not Set true if we are inverting the condition.
     * @param \core_availability\info $info Item we're checking.
     * @return string Text description.
     */
    public function get_description($full, $not, \core_availability\info $info) {
        $key = $not ? 'requires_notenabled' : 'requires_enabled';
        return get_string($key, 'availability_livepractice');
    }

    /**
     * Gets a string for debugging.
     *
     * @return string
     */
    protected function get_debug_string() {
        return self::flag_enabled() ? 'ON' : 'OFF';
    }
}
