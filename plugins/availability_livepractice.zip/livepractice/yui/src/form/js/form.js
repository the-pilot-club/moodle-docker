/**
 * JavaScript for form editing live practice flights conditions.
 *
 * @module moodle-availability_livepractice-form
 */
M.availability_livepractice = M.availability_livepractice || {};

/**
 * @class M.availability_livepractice.form
 * @extends M.core_availability.plugin
 */
M.availability_livepractice.form = Y.Object(M.core_availability.plugin);

/**
 * Initialises this plugin.
 *
 * @method initInner
 */
M.availability_livepractice.form.initInner = function() {
    // Nothing to initialise: the condition has no options.
};

M.availability_livepractice.form.getNode = function() {
    return Y.Node.create('<span class="col-form-label pr-3">' +
            M.util.get_string('title', 'availability_livepractice') + '</span>');
};

M.availability_livepractice.form.fillValue = function() {
    // Nothing to fill: the condition has no options.
};

M.availability_livepractice.form.fillErrors = function() {
    // Nothing to validate.
};
