<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Admin settings for the live practice flights restriction.
 *
 * @package    availability_livepractice
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($ADMIN->fulltree) {
    require_once(__DIR__ . '/lib.php');

    $setting = new admin_setting_configcheckbox(
        'availability_livepractice/enabled',
        get_string('setting_enabled', 'availability_livepractice'),
        get_string('setting_enabled_desc', 'availability_livepractice') . ' ' .
            get_string('toggle_link', 'availability_livepractice',
                (new moodle_url('/availability/condition/livepractice/toggle.php'))->out(false)),
        0
    );
    $setting->set_updatedcallback('availability_livepractice_setting_updated');
    $settings->add($setting);
}
