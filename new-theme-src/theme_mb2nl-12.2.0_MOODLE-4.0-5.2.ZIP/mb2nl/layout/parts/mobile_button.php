<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2026 Mariusz Boloz (lmsstyle.com)
 * @license   PHP and HTML: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later. Other parts: http://themeforest.net/licenses
 *
 */

defined('MOODLE_INTERNAL') || die();

echo '<div class="menu-toggle">
    <span id="themeskipto-mobilenav"></span>
    <button type="button" class="show-menu themereset p-0 lhsmall' . theme_mb2nl_bsfcls(2, '', 'center', 'center') . '"
    aria-controls="main-navigation" aria-expanded="false"><span class="sr-only">' . get_string('menu') . '</span>
    <i class="icon1 bi bi-list" aria-hidden="true"></i>
    <i class="icon2 bi bi-x-lg d-none" aria-hidden="true"></i>
    </button>
</div>';
