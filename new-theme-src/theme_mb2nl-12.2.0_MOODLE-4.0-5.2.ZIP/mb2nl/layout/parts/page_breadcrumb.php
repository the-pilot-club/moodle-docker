<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2026 Mariusz Boloz (lmsstyle.com)
 * @license   PHP and HTML: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later. Other parts: http://themeforest.net/licenses
 *
 */

defined('MOODLE_INTERNAL') || die();

global $OUTPUT, $PAGE;

$headerl = theme_mb2nl_theme_setting($PAGE, 'headerl');
$secnav = theme_mb2nl_theme_setting($PAGE, 'secnav');
$coursemenu = $secnav ? '' : $OUTPUT->context_header_settings_menu();
$modmenu = $secnav ? '' : $OUTPUT->region_main_settings_menu();

$html = '';

$html .= '<div class="page-breadcrumb position-relative breadcrumb_' . $headerl . '">';
$html .= '<div class="container-fluid">';
$html .= '<div class="row">';
$html .= '<div class="col-md-12">';
$html .= '<div class="flexcols">';
$html .= '<div class="breadcrumb">' . $OUTPUT->navbar() . '</div>';
$html .= '<div class="actions' . theme_mb2nl_bsfcls(1, 'wrap', '', 'center') . '">';
$html .= theme_mb2nl_header_actions();
$html .= $OUTPUT->page_heading_button();

if (!theme_mb2nl_theme_setting($PAGE, 'coursepanel')) {
    $html .= ($coursemenu || $modmenu) ? $coursemenu . $modmenu : '';
} else {
    $html .= theme_mb2nl_panel_link();
}

$html .= '</div>';
$html .= '</div>';
$html .= '</div>';
$html .= '</div>';
$html .= '</div>';
$html .= '</div>';

echo $html;
