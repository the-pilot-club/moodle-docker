<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2026 Mariusz Boloz (lmsstyle.com)
 * @license   PHP and HTML: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later. Other parts: http://themeforest.net/licenses
 *
 */




/**
 *
 * Method to get set start options for courses page
 *
 */
function theme_mb2nl_courses_startopts($options, $count = false) {

    $startopts = [];
    $opt2set = [
        'page' => 1,
        'searchstr' => '',
        'categories' => [],
        'excats' => '',
        'catids' => '',
        'instructors' => [],
        'exinst' => '',
        'instids' => '',
        'excludetag' => '',
        'cfields' => [],
        'tags' => [],
        'tagids' => '',
        'extags' => '',
        'lazy' => 0,
        'htag' => 'h2',
        'price' => '-1',
        'courseids' => '',
        'limit' => 0,
        'catlimit' => 0, // This is required for the coursetabs count in the "All" tab.
    ];

    // Unset the page and limit for the count to prevent for creating cache for evry page (pagination).
    if ($count) {
        unset($opt2set['page']);
        unset($opt2set['limit']);
    }

    foreach ($opt2set as $key => $default) {

        if (!isset($options[$key])) {
            $startopts[$key] = $default;
            continue;
        }

        $value = $options[$key];

        if (is_array($default)) {

            $value = $options[$key];

            // Convert string → array if needed.
            if (!is_array($value)) {
                $value = explode(',', (string)$value);
            }

            // RECURSIVE normalization for nested arrays (cfields case).
            $value = theme_mb2nl_array_strval_recursive($value);
        }

        $startopts[$key] = $value;

    }

    ksort($startopts);

    return $startopts;

}




/**
 *
 * Method to get options of the cfields
 *
 */
function theme_mb2nl_array_strval_recursive($data) {

    if (!is_array($data)) {
        return (string)$data;
    }

    $result = [];

    foreach ($data as $key => $value) {

        if (is_array($value)) {
            $result[$key] = theme_mb2nl_array_strval_recursive($value);
        } else {
            $result[$key] = (string)$value;
        }
    }

    return $result;
}



/**
 *
 * Method to get set options for cache id
 *
 */
function theme_mb2nl_courses_cacheid($options, $count = false) {

    global $USER;

    // Keep only allowed keys + defaults.
    $filtered = theme_mb2nl_courses_startopts($options, $count);
    return ($count ? 'ccount_' : 'clist_') . $USER->id . '_' . md5(json_encode($filtered));

}




/**
 *
 * Method to get courses
 *
 */
function theme_mb2nl_get_courses($opt = [], $count = false) {
    global $DB, $CFG, $PAGE;

    $page = isset($opt['page']) ? $opt['page'] : 1;

    // Use cache.
    $cache = cache::make('theme_mb2nl', 'courses');
    $cacheid = theme_mb2nl_courses_cacheid($opt, $count);

    $opt['perpage'] = $CFG->coursesperpage;
    $opt['limitfrom'] = ($page - 1) * $opt['perpage'];

    if (isset($opt['limit']) && $opt['limit']) {
        $opt['perpage'] = $opt['limit'];
        $opt['limitfrom'] = 0;
    }

    // Get course list cache.
    if ($cache->get($cacheid)) {
        return $cache->get($cacheid);
    }

    $params = [];
    $sqlwhere = ' WHERE 1=1';
    $sqlorder = '';
    $sql = '';

    if ($count) {
        $sql .= 'SELECT COUNT(c.id) FROM {course} c';
    } else {
        $sql .= 'SELECT DISTINCT c.* FROM {course} c';
    }

    // Check expired courses.
    if (!theme_mb2nl_theme_setting($PAGE, 'expiredcourses')) {
        $sqlwhere .= ' AND (c.enddate=0 OR c.enddate>' . theme_mb2nl_get_user_date() . ')';
    }

    // Check for visible categories and courses.
    $opt['onlyid'] = 1;
    $visiblecats = theme_mb2nl_get_categories($opt);
    $visiblecourses = theme_mb2nl_visible_course_ids($visiblecats);

    // Filter for hidden categories.
    if (!empty($visiblecats)) {
        list($canseecatsql, $canseecatparams) = $DB->get_in_or_equal($visiblecats);
        $params = array_merge($params, $canseecatparams);
        $sqlwhere .= ' AND c.category ' . $canseecatsql;
    }

    // Filter for visible courses.
    if (!empty($visiblecourses)) {
        list($canseecoursesql, $canseecourseparams) = $DB->get_in_or_equal($visiblecourses);
        $params = array_merge($params, $canseecourseparams);
        $sqlwhere .= ' AND c.id ' . $canseecoursesql;
    } else {
        return $count ? 0 : [];
    }

    // Filter exclude courses (OLD).
    if (isset($opt['courseids']) &&  $opt['courseids'] && $opt['excourses']) {
        $isnot = '';
        $opt['courseids'] = explode(',', $opt['courseids']);

        if ($opt['excourses'] === 'exclude') {
            $isnot = count($opt['courseids']) > 1 ? 'NOT ' : '!';
        }

        list($coursesnsql, $coursesparams) = $DB->get_in_or_equal($opt['courseids']);
        $params = array_merge($params, $coursesparams);
        $sqlwhere .= ' AND c.id ' . $isnot . $coursesnsql;
    }

    // Filter instructors.
    if (!empty($opt['instructors']) || (isset($opt['instids']) && $opt['instids'] && $opt['exinst'])) {
        $isnot = '';

        // Set instructor filter for the course shortcode.
        if (isset($opt['instids'])) {
            $opt['instructors'] = explode(',', $opt['instids']);

            if ($opt['exinst'] === 'exclude') {
                $isnot = 'NOT ';
            }
        }

        list($instructorsinsql, $instructorsparams) = $DB->get_in_or_equal($opt['instructors']);
        $params = array_merge($params, $instructorsparams);
        $sqlwhere .= ' AND ' . $isnot . 'EXISTS(SELECT ra.id FROM {role_assignments} ra JOIN {context} cx ON ra.contextid = cx.id';
        $sqlwhere .= ' AND cx.contextlevel = ' . CONTEXT_COURSE . ' WHERE cx.instanceid = c.id AND ra.roleid = ' .
        theme_mb2nl_user_roleid(true) . ' AND ra.userid ' . $instructorsinsql . ')';
    }

    // Filter price.
    if (isset($opt['price']) && ($opt['price'] == 0 || $opt['price'] == 1)) {
        $params[] = ENROL_INSTANCE_ENABLED;
        $payenrol = theme_mb2nl_pay_enrolements();
        list($priceinsql, $priceparams) = $DB->get_in_or_equal($payenrol);
        $params = array_merge($params, $priceparams);
        $isnot = '';

        if ($opt['price'] == 0) {
            $isnot = 'NOT ';
        }

        $sqlwhere .= ' AND ' . $isnot . 'EXISTS(SELECT er.id FROM {enrol} er WHERE er.courseid=c.id AND er.status=? AND er.enrol ' .
        $priceinsql . ')';
    }

    // Exlude tags.
    $opt['excludetag'] = theme_mb2nl_course_extags();
    if ($opt['excludetag'][0]) {
        list($extaginsql, $extagparams) = $DB->get_in_or_equal($opt['excludetag']);
        $params = array_merge($params, $extagparams);

        $sqlwhere .= ' AND NOT EXISTS(SELECT t.id FROM {tag} t JOIN {tag_instance} ti ON ti.tagid=t.id JOIN {context} cx';
        $sqlwhere .= ' ON cx.id=ti.contextid WHERE c.id=cx.instanceid';
        $sqlwhere .= ' AND cx.contextlevel = ' . CONTEXT_COURSE;
        $sqlwhere .= ' AND t.id ' . $extaginsql;
        $sqlwhere .= ')';
    }

    // Filter tags.
    if (!empty($opt['tags'])) {
        list($extaginsql, $extagparams) = $DB->get_in_or_equal($opt['tags']);
        $params = array_merge($params, $extagparams);

        $sqlwhere .= ' AND EXISTS(SELECT t.id FROM {tag} t JOIN {tag_instance} ti ON ti.tagid=t.id JOIN {context} cx';
        $sqlwhere .= ' ON cx.id=ti.contextid WHERE c.id=cx.instanceid';
        $sqlwhere .= ' AND cx.contextlevel = ' . CONTEXT_COURSE;
        $sqlwhere .= ' AND t.id ' . $extaginsql;
        $sqlwhere .= ')';
    }

    // Filter tags for shortcodes.
    if (isset($opt['tagids'], $opt['extags']) && $opt['tagids'] && $opt['extags']) {
        $isnot = '';
        $tagsarr = explode(',', $opt['tagids']);

        if ($opt['extags'] === 'exclude') {
            $isnot = 'NOT ';
        }

        list($extaginsql, $extagparams) = $DB->get_in_or_equal($tagsarr);
        $params = array_merge($params, $extagparams);

        $sqlwhere .= ' AND ' .$isnot. 'EXISTS(SELECT t.id FROM {tag} t JOIN {tag_instance} ti ON ti.tagid=t.id JOIN {context} cx';
        $sqlwhere .= ' ON cx.id=ti.contextid WHERE c.id=cx.instanceid';
        $sqlwhere .= ' AND cx.contextlevel = ' . CONTEXT_COURSE;
        $sqlwhere .= ' AND t.id ' . $extaginsql;
        $sqlwhere .= ')';
    }

    // Filter search.
    // Based on get_courses_search.
    if (isset($opt['searchstr'])  && $opt['searchstr'] !== '') {
        $searchstr = strip_tags($opt['searchstr']);
        $searchstr = trim($searchstr);
        $params[] = '%' . $searchstr . '%';
        $concat = $DB->sql_concat("COALESCE(c.summary, '')", "' '", 'c.fullname', "' '", 'c.idnumber', "' '", 'c.shortname');
        $sqlwhere .= ' AND (' . $DB->sql_like($concat, '?', false, true, false);

        // Search by course custom fileds.
        $params[] = '%' . $searchstr . '%';
        $sqlwhere .= ' OR EXISTS(SELECT cf.id FROM {customfield_data} cf JOIN {context} cx ON cx.id=cf.contextid';
        $sqlwhere .= ' WHERE c.id=cx.instanceid';
        $sqlwhere .= ' AND ' . $DB->sql_like('cf.value', '?', false, true, false);
        $sqlwhere .= '))';
    }

    // Filter by custom fileds.
    if (isset($opt['cfields']) && !empty($opt['cfields'])) {
        foreach ($opt['cfields'] as $fid => $fvals) {
            if (!count($fvals)) {
                continue;
            }

            if ($fvals[0] == 0) {
                continue;
            }

            $sqlwhere .= ' AND EXISTS(SELECT cf.id, cf.fieldid FROM {customfield_data} cf JOIN {context} cx ON cx.id=cf.contextid';
            $sqlwhere .= ' WHERE c.id=cx.instanceid';
            $sqlwhere .= ' AND cx.contextlevel=' . CONTEXT_COURSE;
            $sqlwhere .= ' AND cf.fieldid=' . $fid;
            $sqlwhere .= count($fvals) == 1 ? ' AND cf.value=' . $fvals[0] : ' AND cf.value IN (' . implode(',', $fvals) . ')';
            $sqlwhere .= ')';
        }
    }

    $sqlorder .= ' ORDER BY c.sortorder';

    if ($count) {
        $coursecount = $DB->count_records_sql($sql . $sqlwhere, $params);
        $cache->set($cacheid, $coursecount);
        return $coursecount;
    }

    $courselist = $DB->get_records_sql($sql . $sqlwhere . $sqlorder, $params, $opt['limitfrom'], $opt['perpage']);
    $cache->set($cacheid, $courselist);
    return $courselist;

}





/**
 *
 * Method to get visible courses
 *
 */
function theme_mb2nl_visible_course_ids($visiblecats = []) {

    global $DB, $SITE, $USER;

    if (empty($visiblecats)) {
        return [];
    }

    $visiblecourses = [];

    // Cache per user.
    $cache = cache::make('theme_mb2nl', 'courses');
    $cacheid = 'vcu_' . $USER->id . '_' . md5(json_encode($visiblecats));

    if ($cached = $cache->get($cacheid)) {
        return $cached;
    }

    // Prepare category placeholders.
    list($catsql, $catparams) = $DB->get_in_or_equal($visiblecats, SQL_PARAMS_NAMED, 'cat');

    // Step 1: Fetch all visible courses.
    $visiblecourses = $DB->get_fieldset_sql(
        'SELECT id FROM {course} WHERE visible = 1 AND category ' . $catsql . ' AND id <> :siteid',
        array_merge($catparams, ['siteid' => $SITE->id]));

    // Step 2: Fetch hidden courses.
    $hiddencourses = $DB->get_records_sql(
        'SELECT id FROM {course} WHERE visible = 0 AND category ' . $catsql . ' AND id <> :siteid',
        array_merge($catparams, ['siteid' => $SITE->id]));

    // Step 3: Preload contexts for hidden courses to avoid one query per course.
    $contextids = [];
    foreach ($hiddencourses as $course) {
        $contextids[] = context_course::instance($course->id, IGNORE_MISSING)->id;
    }
    context_helper::preload_contexts_by_id($contextids);

    // Step 4: Check capability only for hidden courses (for better performance).
    foreach ($hiddencourses as $course) {
        $cctx = context_course::instance($course->id, IGNORE_MISSING);
        if (has_capability('moodle/course:viewhiddencourses', $cctx)) {
            $visiblecourses[] = $course->id;
        }
    }

    // Cache.
    $cache->set($cacheid, $visiblecourses);
    return $visiblecourses;

}






/**
 *
 * Method to set custom fields data attribute to filter courses by the URL parameters
 *
 */
function theme_mb2nl_cfileds_for_data_att($tourl = true) {
    global $PAGE;

    $filterfields = theme_mb2nl_theme_setting($PAGE, 'filterfields');
    $params = [];

    if (!$filterfields) {
        return;
    }

    $fields = preg_split('/\s*\R\s*/', trim($filterfields));

    foreach ($fields as $field) {
        $line = explode('|', $field);

        if ($urlparam = optional_param($line[0], 0, PARAM_RAW)) {
            $params[trim($line[0])] = $urlparam;
        }
    }

    if ($tourl) {
        return urlencode(json_encode($params));
    } else {
        return $params;
    }

}




/**
 *
 * Method to get course filter form
 *
 */
function theme_mb2nl_filter_cfileds($params = []) {

    global $PAGE;

    $output = '';
    $filterfields = theme_mb2nl_theme_setting($PAGE, 'filterfields');

    if (!$filterfields) {
        return;
    }

    $output .= '<input type="hidden" name="cfields" value="">';

    $fileds = preg_split('/\s*\R\s*/', trim($filterfields));

    foreach ($fileds as $f) {

        $line = explode('|', $f);

        // Check if filed exists.
        $field = theme_mb2nl_is_selectfield($line[0]);

        if (!$field) {
            continue;
        }

        $checkbox = isset($line[1]) && $line[1] !== 'checkbox' ? 0 : 1;
        $output .= theme_mb2nl_selectfield_filterblock($field, $checkbox, $params);

    }

    return $output;

}







/**
 *
 * Method to get course filter form
 *
 */
function theme_mb2nl_selectfield_filterblock($field, $checkbox = 1, $params = []) {

    $output = '';

    $id = $field->id;
    $options = theme_mb2nl_selectfield_options($id);

    if (count($options) <= 1) {
        return;
    }

    $output .= '<div class="filter-block">';
    $output .= theme_mb2nl_courses_filter_heading($field->name);
    $output .= '<div id="cfield_block_' . $id . '" class="filter-content">';
    $output .= '<ul class="filter-cfield_' . $id . '">';

    foreach ($options as $v => $name) {
        if ($checkbox && $v == 0) {
            continue;
        }

        $fieldtype = !$checkbox ? theme_mb2nl_cfiled_radiobox($field, $v, $name, $params) :
        theme_mb2nl_cfiled_checkbox($field, $v, $name, $params);

        $output .= '<li class="filter-form-field">' . $fieldtype. '</li>';
    }

    $output .= '</ul>';
    $output .= '</div>'; // ...filter-content
    $output .= '</div>'; // ...filter-block

    return $output;

}








/**
 *
 * Method to get filter filed - checkbox
 *
 */
function theme_mb2nl_cfiled_checkbox($field, $v, $name, $params) {

    $output = '';

    $ccount = theme_mb2nl_get_cfileds_courses_count($field->id, $v);
    $coursescount = ' <span class="info">(' . $ccount . ')</span>';
    $isid = 'cfield_' . $field->id . '_' . $v;
    $disabled = !$ccount ? ' disabled' : '';
    $checked = '';

    // Get params from the URL.
    $checked = isset($params[$field->shortname]) ? $params[$field->shortname] == $v : 0;
    if ($checked) {
        $checked = ' checked';
        $disabled = ' disabled';
    }

    $flexcls = theme_mb2nl_bsfcls(2, '', 'center', 'center');

    $output .= '<div class="field-container' . $disabled . '">';
    $output .= '<label for="' . $isid . '">';
    $output .= '<input class="mb2filter-inpt" type="checkbox" id="' . $isid . '" name="cfields[' . $field->id .
    '][]" value="' . $v . '"' . $disabled . $checked . '>';
    $output .= '<span class="field-mark position-relative lhsmall' . $flexcls . '">
    <i class="bi bi-check' . $flexcls . '"></i></span>';
    $output .= theme_mb2nl_format_str($name) . ' ' . $coursescount;
    $output .= '</label>';
    $output .= '</div>'; // ...field-container

    return $output;

}








/**
 *
 * Method to get filter filed - radiobox
 *
 */
function theme_mb2nl_cfiled_radiobox($field, $v, $name, $params) {

    $output = '';
    $ccount = theme_mb2nl_get_cfileds_courses_count($field->id, $v);
    $coursescount = ' <span class="info">(' . $ccount . ')</span>';
    $isid = 'cfield_' . $field->id . '_' . $v;
    $name = $v == 0 ? get_string('all') : $name;
    $checked = $v == 0 ? ' checked' : '';
    $disabled = !$ccount ? ' disabled' : '';

    // Get params from the URL.
    $paramschecked = isset($params[$field->shortname]) ? ($params[$field->shortname] == $v && $params[$field->shortname] > 0) : 0;
    $checked = $paramschecked ? ' checked' : $checked;
    $flexcls = theme_mb2nl_bsfcls(2, '', 'center', 'center');

    // Disable all boxes if user set param in the URL.
    if (isset($params[$field->shortname]) && $params[$field->shortname] > 0) {
        $disabled = ' disabled';
    }

    $output .= '<div class="field-container' . $disabled . '">';
    $output .= '<label for="' . $isid . '">';
    $output .= '<input class="mb2filter-inpt" type="radio" id="' . $isid . '" name="cfields[' . $field->id . '][]" value="' .
    $v . '"' . $checked . $disabled . '>';
    $output .= '<span class="field-mark position-relative lhsmall' . $flexcls . '">
    <i class="bi bi-circle-fill' . $flexcls . '"></i></span>';
    $output .= theme_mb2nl_format_str($name) . ' ' . $coursescount;
    $output .= '</label>';

    $output .= '</div>'; // ...field-container

    return $output;

}






/**
 *
 * Method to get course filter form
 *
 */
function theme_mb2nl_selectfield_options($id = 0) {

    global $DB;

    // Get cache.
    $cache = cache::make('theme_mb2nl', 'coursefield');
    $cacheid = 'coursefield_opts_' . $id;

    if ($cache->get($cacheid)) {
        return $cache->get($cacheid);
    }

    $params = ['id' => $id];

    $recordsql = 'SELECT id, configdata FROM {customfield_field} WHERE id=:id';

    if (!$DB->record_exists_sql($recordsql, $params)) {
        return;
    }

    // Get configdata.
    $data = json_decode($DB->get_record_sql($recordsql, $params)->configdata);

    // Get options array.
    // This is based on a native Moodle solution.
    $options = preg_split('/\s*\n\s*/', trim($data->options));

    // Set cache.
    $cache->set($cacheid, array_merge([''], $options));

    return array_merge([''], $options);

}




/**
 *
 * Method to get course filter form
 *
 */
function theme_mb2nl_is_selectfield($shortname, $urlparams = []) {

    global $DB;

    $shortname = trim((string)$shortname);
    if (empty($shortname)) {
        return false;
    }

    // Set cache.
    $cache = cache::make('theme_mb2nl', 'coursefield');
    $cacheid = 'cfield_' . md5($shortname . json_encode($urlparams));

    if ($cache->has($cacheid)) {
        return $cache->get($cacheid);
    }

    $result = $DB->get_record('customfield_field', ['shortname' => $shortname, 'type' => 'select']);

    // Set cache.
    $cache->set($cacheid, $result);
    return $result;

}





/**
 *
 * Method to check if there are course filters
 *
 */
function theme_mb2nl_is_course_filters() {
    global $PAGE;

    $coursegrid = theme_mb2nl_is_course_list();
    $coursepage = ($PAGE->pagetype === 'course-index' || $PAGE->pagetype === 'course-index-category');

    if (!$coursepage || !$coursegrid) {
        return;
    }

    return true;

}





/**
 *
 * Method to get course filter position variable.
 *
 */
function theme_mb2nl_courses_filterpos() {

    global $PAGE;

    $opts = ['top', 'sidebar'];
    $parampos = optional_param('filterpos', '', PARAM_ALPHANUMEXT);

    if ($parampos) {
        if (in_array($parampos, $opts)) {
            return $parampos;
        }
    }

    return theme_mb2nl_theme_setting($PAGE, 'filterpos');

}




/**
 *
 * Method to get course filter form
 *
 */
function theme_mb2nl_courses_filter_form($sidebar = true) {
    global $PAGE;

    $filterpos = theme_mb2nl_courses_filterpos();
    $categoryid = optional_param('categoryid', 0, PARAM_INT);
    $tagid = optional_param('tagid', '', PARAM_RAW);
    $teacherid = optional_param('teacherid', '', PARAM_RAW);

    if (($sidebar && $filterpos === 'top') || (!$sidebar && $filterpos === 'sidebar')) {
        return;
    }

    $output = '';

    if (!theme_mb2nl_is_course_filters()) {
        return;
    }

    $output .= $filterpos === 'sidebar' ? theme_mb2nl_course_top_bar() : ''; // This is require for mobile filter.

    $output .= '<div id="cfilter_wrap" class="cfilter-wrap position-relative filterpos' . $filterpos . '">';
    $output .= '<button type="button" class="themereset filter-close position-absolute lhsmall p-0"><span class="sr-only">' .
    get_string('closebuttontitle') . '</span><i class="bi bi-x-lg" aria-hidden="true"></i></button>';
    $output .= '<form name="theme-course-filter" class="theme-course-filter" action="index.php" method="POST">';
    $output .= '<input type="hidden" id="sesskey" name="sesskey" value="' . sesskey() . '">';
    $output .= '<div class="inner' . theme_mb2nl_bsfcls(1) . '">';

    // Categories filter.
    if (theme_mb2nl_is_cached_filter('categories') === true) {
        $output .= theme_mb2nl_courses_filter_categories($categoryid);
    }

    // Tags filter.
    if (theme_mb2nl_is_cached_filter('tags') === true) { // Tags.
        $output .= theme_mb2nl_courses_filter_tags($tagid);
    }

    // Instructors filter.
    if (theme_mb2nl_is_cached_filter('instructors') === true) { // Instructors.
        $output .= theme_mb2nl_courses_filter_instructors($teacherid);
    }

    // Price filter.
    if (theme_mb2nl_is_cached_filter('courseprice') === true) {
        $output .= theme_mb2nl_courses_filter_price();
    }

    // Custom fileds filter.
    if (theme_mb2nl_is_cached_filter('cfields') === true) {
        $output .= theme_mb2nl_filter_cfileds(theme_mb2nl_cfileds_for_data_att(false));
    }

    // Load filter items by AJAX if is required.
    if (!empty(theme_mb2nl_load_filters())) {
        $output .= theme_mb2nl_preload();
        $PAGE->requires->js_call_amd('theme_mb2nl/courselist', 'setCoursesFilters');
    }

    $output .= '</div>';
    $output .= '</form>';
    $output .= '</div>';

    return $output;

}



/**
 *
 * Method to check if filters need to be loaded
 *
 */
function theme_mb2nl_load_filters() {

    $filters = [];

    // Categories — always check cache.
    if (!theme_mb2nl_is_cached_filter('categories')) {
        $filters[] = 'categories';
    }

    // Tags.
    $tags = theme_mb2nl_is_cached_filter('tags');
    if ($tags !== -1 && !$tags) {
        $filters[] = 'tags';
    }

    // Custom fields.
    $cfields = theme_mb2nl_is_cached_filter('cfields');
    if ($cfields !== -1 && !$cfields) {
        $filters[] = 'cfields';
    }

    // Price filter.
    $courseprice = theme_mb2nl_is_cached_filter('courseprice');
    if ($courseprice !== -1 && !$courseprice) {
        $filters[] = 'courseprice';
    }

    // Instructors.
    $instructors = theme_mb2nl_is_cached_filter('instructors');
    if ($instructors !== -1 && !$instructors) {
        $filters[] = 'instructors';
    }

    return $filters;
}




/**
 *
 * Method to check if courses tree exists
 *
 */
function theme_mb2nl_is_cached_filter($type) {
    global $CFG, $PAGE, $USER;

    if ($type === 'tags') {
        if (!theme_mb2nl_theme_setting($PAGE, 'coursetags')) {
            return -1;
        }

        $cache = cache::make('theme_mb2nl', 'coursetags');
        $opts = theme_mb2nl_tags_startopts(['taglimit' => $CFG->coursesperpage]);
        $cacheid = 'ctli_' . $USER->id . '_' . md5(json_encode($opts));
        return $cache->has($cacheid);

    } else if ($type === 'instructors') {
        if (!theme_mb2nl_theme_setting($PAGE, 'coursinstructor')) {
            return -1;
        }

        $cache = cache::make('theme_mb2nl', 'userroles');
        $opts = theme_mb2nl_teachers_startopts(['limit' => $CFG->coursesperpage]);
        $cacheid = 'tdata_' . $USER->id . '_' . md5(json_encode($opts));

        return $cache->has($cacheid);

    } else if ($type === 'courseprice') {
        if (!theme_mb2nl_theme_setting($PAGE, 'courseprice')) {
            return -1;
        }

        $cache = cache::make('theme_mb2nl', 'courses');
        $cacheid = 'paidcc_' . $USER->id;
        return $cache->has($cacheid);

    } else if ($type === 'cfields') {
        $cfields = theme_mb2nl_theme_setting($PAGE, 'filterfields');

        if (!$cfields) {
            return -1;
        }

        $fields = preg_split('/\s*\R\s*/', trim($cfields));
        $cache = cache::make('theme_mb2nl', 'coursefield');

        foreach ($fields as $field) {
            $line = explode('|', $field);
            $cacheid = 'cfield_' . md5(trim($line[0]) . json_encode([]));

            if (!$cache->has($cacheid)) {
                return false;
            }
        }

        return true;

    } else {
        $cache = cache::make('theme_mb2nl', 'categories');
        $copts = theme_mb2nl_categories_startopts(['catlimit' => $CFG->coursesperpage, 'withcnt' => true, 'parentid' => 0]);
        $cacheid = 'vca_' . $USER->id . '_' . md5(json_encode($copts));

        return $cache->has($cacheid);
    }

}





/**
 *
 * Method to get course filter form
 *
 */
function theme_mb2nl_courses_filter_price() {
    global $PAGE;

    $output = '';
    $courseprice = theme_mb2nl_theme_setting($PAGE, 'courseprice');

    if (!$courseprice) {
        return;
    }

    $allcc = theme_mb2nl_get_courses([], true);
    $paidcc = theme_mb2nl_get_paid_courses_count();

    // Validate BEFORE calculations.
    if (!is_int($allcc) || !is_int($paidcc)) {
        return;
    }

    // Get free courses.
    $freecc = ($allcc - $paidcc);

    if (!$paidcc || !$freecc) {
        return;
    }

    $flexcls = theme_mb2nl_bsfcls(2, '', 'center', 'center');

    $items = [
        ['id' => 'price_all', 'value' => '-1', 'label' => get_string('all'), 'count' => $allcc],
        ['id' => 'price_free', 'value' => '0', 'label' => get_string('noprice', 'theme_mb2nl'), 'count' => $freecc],
        ['id' => 'price_paid', 'value' => '1', 'label' => get_string('paid', 'theme_mb2nl'), 'count' => $paidcc],
    ];

    $output .= '<div class="filter-block">';

    $output .= theme_mb2nl_courses_filter_heading(get_string('price', 'theme_mb2nl'));

    $output .= '<div id="cfilter_price" class="filter-content">';
    $output .= '<ul class="filter-price">';

    foreach ($items as $item) {
        $ischecked = $item['value'] == '-1' ? ' checked' : '';

        $output .= '<li class="filter-form-field">';
        $output .= '<div class="field-container">';
        $output .= '<label for="' . $item['id'] . '">';
        $output .= '<input class="mb2filter-inpt" type="radio" id="' . $item['id'] . '" name="price" value="' .
        $item['value'] . '" ' . $ischecked . '>';
        $output .= '<span class="field-mark position-relative lhsmall' . $flexcls . '">
        <i class="bi bi-circle-fill' . $flexcls . '"></i></span>';
        $output .= $item['label'] . ' <span class="info">(' . $item['count'] . ')</span></label>';
        $output .= '</div>';
        $output .= '</li>';
    }

    $output .= '</ul>';
    $output .= '</div>'; // ...filter-content
    $output .= '</div>';

    return $output;

}


/**
 *
 * Method to get course filter form
 *
 */
function theme_mb2nl_courses_filter_instructors_items($teacherid = '', $opts = []) {

    global $CFG;

    $output = '';

    // Get tags.
    $topts = [
        'limit' => $CFG->coursesperpage,
    ];

    if (!empty($opts)) {
        $topts = $opts;
    }

    $instructors = theme_mb2nl_teachers_data($topts);

    if (empty($instructors)) {
        return;
    }

    $flexcls = theme_mb2nl_bsfcls(2, '', 'center', 'center');
    $urlteachers = $teacherid ? explode('|', $teacherid) : [];

    foreach ($instructors as $instructor) {

        if (!$instructor['ccount']) {
            continue;
        }

        $disabled = '';
        $checked = '';

        if (in_array($instructor['id'], $urlteachers)) {
            $checked = ' checked';
            $disabled = ' disabled';
        }

        $coursescount = ' <span class="info">(' . $instructor['ccount'] . ')</span>';

        $output .= '<li class="filter-form-field">';
        $output .= '<div class="field-container' . $disabled . '">';
        $output .= '<label for="instructorid_' . $instructor['id'] . '">';
        $output .= '<input class="mb2filter-inpt" type="checkbox" id="instructorid_' . $instructor['id']
        . '" name="instructors[]" value="' . $instructor['id'] . '"' . $checked . $disabled . '>';
        $output .= '<span class="field-mark position-relative lhsmall' . $flexcls . '">
        <i class="bi bi-check' . $flexcls . '"></i></span>';
        $output .= $instructor['firstname'] . ' ' . $instructor['lastname'] . $coursescount .'</label>';
        $output .= '</div>'; // ...field-container
        $output .= '</li>';
    }

    return $output;

}





/**
 *
 * Method to get course filter form
 *
 */
function theme_mb2nl_courses_filter_instructors($teacherid = 0) {
    global $CFG, $PAGE;

    $output = '';
    $cls = '';
    $clslist = '';

    if (!theme_mb2nl_theme_setting($PAGE, 'coursinstructor')) {
        return;
    }

    $teachercount = theme_mb2nl_get_all_teachers(['count' => 1]);

    $output .= '<div class="filter-block">';
    $output .= '<input type="hidden" name="instructors" value="">';

    $urlteachers = $teacherid ? explode('|', $teacherid) : [];

    if (!empty($urlteachers)) {
        foreach ($urlteachers as $teacher) {
            $output .= '<input class="mb2filter-inpt" type="hidden" name="instructors[]" value="' . $teacher. '">';
        }
    }

    $output .= theme_mb2nl_courses_filter_heading(get_string('instructors', 'theme_mb2nl'));

    $output .= '<div id="cfilter_instructors" class="filter-content filter-instructors' . $cls . '">';
    $output .= '<ul class="filter-instructors-lis' . $clslist . '">';

    $output .= theme_mb2nl_courses_filter_instructors_items($teacherid);

    if ($CFG->coursesperpage < $teachercount) {
        $output .= '<li>' . theme_mb2nl_categories_loadmore('instructor', 0, $teachercount) . '</li>';
    }

    $output .= '</ul>';

    $output .= '</div>'; // ...filter-instructors
    $output .= '</div>';

    return $output;

}




/**
 *
 * Method to get course filter tags form
 *
 */
function theme_mb2nl_courses_filter_tags_items($tagid, $opts = []) {

    global $CFG;

    $output = '';
    $flexcls = theme_mb2nl_bsfcls(2, '', 'center', 'center');

    // Get tags.
    $topts = [
        'taglimit' => $CFG->coursesperpage,
    ];

    if (!empty($opts)) {
        $topts = $opts;
    }

    $coursetags = theme_mb2nl_course_tags($topts);
    $urltags = $tagid ? explode('|', $tagid) : [];

    foreach ($coursetags as $tag) {
        $courses = theme_mb2nl_get_tags_course_count($tag->id);
        $coursescount = ' <span class="info">(' . $courses . ')</span>';

        if (!$courses) {
            continue;
        }

        $disabled = '';
        $checked = '';

        if (in_array($tag->id, $urltags)) {
            $checked = ' checked';
            $disabled = ' disabled';
        }

        $output .= '<li class="filter-form-field">';
        $output .= '<div class="field-container' . $disabled . '">';
        $output .= '<label for="tagid_' . $tag->id . '">';
        $output .= '<input class="mb2filter-inpt" type="checkbox" id="tagid_' . $tag->id . '" name="tags[]" value="' .
        $tag->id . '"' . $checked . $disabled . '>';
        $output .= '<span class="field-mark position-relative lhsmall' . $flexcls . '">
        <i class="bi bi-check' . $flexcls . '"></i></span>';
        $output .= $tag->rawname . $coursescount .'</label>';
        $output .= '</div>'; // ...field-container
        $output .= '</li>';
    }

    return $output;

}



/**
 *
 * Method to get course filter tags form
 *
 */
function theme_mb2nl_courses_filter_tags($tagid = '') {
    global $CFG, $PAGE;

    $coursetagsset = theme_mb2nl_theme_setting($PAGE, 'coursetags');

    $cls = '';
    $clslist = '';
    $output = '';

    if (!$coursetagsset) {
        return;
    }

    $tagcount = theme_mb2nl_course_tags(['count' => 1], 't.id');

    $output .= '<div class="filter-block">';
    $output .= '<input type="hidden" name="tags" value="">';

    // This is required for the pagination links if the tagid in the tree is not loaded.
    $urltags = $tagid ? explode('|', $tagid) : [];
    if (!empty($urltags)) {
        foreach ($urltags as $tag) {
            $output .= '<input class="mb2filter-inpt" type="hidden" name="tags[]" value="' . $tag . '">';
        }
    }

    $output .= theme_mb2nl_courses_filter_heading(get_string('tags'));

    $output .= '<div id="cfilter_tags" class="filter-content filter-tags' . $cls . '">';
    $output .= '<ul class="filter-tags-list' . $clslist . '">';

    $output .= theme_mb2nl_courses_filter_tags_items($tagid);

    if ($CFG->coursesperpage < $tagcount) {
        $output .= '<li>' . theme_mb2nl_categories_loadmore('tag', 0, $tagcount) . '</li>';
    }

    $output .= '</ul>';

    $output .= '</div>';
    $output .= '</div>';

    return $output;

}






/**
 *
 * Method to get category record
 *
 */
function theme_mb2nl_category_idbyname($name) {

    global $DB;

    if (is_numeric($name)) {
        return $name;
    }

    $params = ['name' => trim($name)];

    $recordsql = 'SELECT id FROM {course_categories} WHERE ' . $DB->sql_like('name', ':name', false);

    if (!$DB->record_exists_sql($recordsql, $params)) {
        return 0;
    }

    return $DB->get_record_sql($recordsql, $params)->id;

}









/**
 *
 * Method to get category record
 *
 */
function theme_mb2nl_get_category_record($categoryid, $fields = '*') {
    global $DB;

    // Get cache.
    $cache = cache::make('theme_mb2nl', 'category');
    $cacheid = 'cat_' . $categoryid;

    if ($category = $cache->get($cacheid)) {
        return $category;
    }

    $category = $DB->get_record('course_categories', ['id' => $categoryid], $fields);

    if (!$category) {
        return null;
    }

    // Set cache.
    $cache->set($cacheid, $category);
    return $category;

}






/**
 *
 * Method to get categories tree
 *
 */
function theme_mb2nl_course_path($catid) {

    $cats = [];

    $cache = cache::make('theme_mb2nl', 'category');
    $cacheid = 'category_path_' . $catid;

    if ($cache->get($cacheid)) {
        return $cache->get($cacheid);
    }

    $fields = 'id,name,path';
    $category = theme_mb2nl_get_category_record($catid, $fields);
    $path = substr($category->path, 1);
    $categories = explode('/', $path);

    foreach ($categories as $c) {
        $cats[] = theme_mb2nl_get_category_record($c, $fields);
    }

    $cache->set($cacheid, $cats);

    return $cats;

}




/**
 *
 * Method to get categories tree
 *
 */
function theme_mb2nl_course_path_html($catid) {
    global $CFG;

    if ($CFG->version < 2025100600) {
        require_once($CFG->libdir . '/navigationlib.php');
    }

    $output = '';
    $homepage = get_home_page();
    $homestr = get_string('myhome');

    if ($homepage == HOMEPAGE_SITE) {
        $homestr = get_string('home');
    } else if ($homepage == HOMEPAGE_MYCOURSES) {
        $homestr = get_string('mycourses');
    }

    $categories = theme_mb2nl_course_path($catid);

    $output .= '<ul class="course-categories-tree' . theme_mb2nl_bsfcls(2, 'wrap', '', 'center') . '">';

    $output .= '<li class="' .theme_mb2nl_bsfcls(2, '', '', 'center') . '">';
    $output .= '<a class="tree-link home-link mb2mr-1' .theme_mb2nl_bsfcls(2, '', '', 'center') . '" href="' .
    new moodle_url('/') . '"><span class="sr-only">' . $homestr . '</span><i class="ri-home-line"></i></a>';
    $output .= '</li>';

    $output .= '<li class="' .theme_mb2nl_bsfcls(2, '', '', 'center') . '">';
    $output .= '<a class="tree-link" href="' . new moodle_url('/course/'). '">' . get_string('courses') . '</a>';
    $output .= '</li>';

    foreach ($categories as $category) {
        $catlink = new moodle_url('/course/index.php', ['categoryid' => $category->id]);
        $output .= '<li class="' . theme_mb2nl_bsfcls(2, '', '', 'center') . '">';
        $output .= '<a class="tree-link" href="' . $catlink . '">' . theme_mb2nl_format_str($category->name) . '</a>';
        $output .= '</li>';
    }

    $output .= '</ul>';

    return $output;

}



/**
 *
 * Method to set categories options
 *
 */
function theme_mb2nl_categories_startopts($options) {

    $startopts = [];
    $opt2set = [
        'categories' => [],
        'catlimit' => 0,
        'catlimitfrom' => 0,
        'notempty' => false,
        'onlyid' => 0,
        'parentid' => null,
        'withcnt' => false,
        'catids' => '',
        'excats' => '',
    ];

    foreach ($opt2set as $key => $default) {

        if (!isset($options[$key])) {
            $startopts[$key] = $default;
            continue;
        }

        $value = $options[$key];

        // Only normalize fields that are defined as arrays in defaults.
        if (is_array($default)) {

            if (!is_array($value)) {
                $value = explode(',', (string)$value);
            }

            // Convert all values to string.
            $value = array_map('strval', $value);
        }

        $startopts[$key] = $value;

    }

    ksort($startopts);

    return $startopts;

}





/**
 *
 * Method to get user visible categories based on the core_course_category::get_all()
 *
 */
function theme_mb2nl_get_categories($opts = []) {

    global $CFG, $DB, $USER;

    $categories = [];
    $onlyid = isset($opts['onlyid']) ? $opts['onlyid'] : 0;
    $withcnt = isset($opts['withcnt']) ? $opts['withcnt'] : false;
    $withcnt = !$onlyid && $withcnt;
    $notempty = $opts['notempty'] ?? false; // Set for the cache ID.
    $joinc = ($notempty && !$onlyid);
    $catlimitfrom = $opts['catlimitfrom'] ?? 0;
    $catlimit  = $opts['catlimit'] ?? 0;
    $parentid = isset($opts['parentid']) ? $opts['parentid'] : null;
    $parentid = is_array($parentid) ? array_shift($parentid) : $parentid; // This is required for the 'categories' [] param.

    $cache = cache::make('theme_mb2nl', 'categories');
    $cacheid = 'vca_' . $USER->id . '_' . md5(json_encode(theme_mb2nl_categories_startopts($opts)));

    if ($cached = $cache->get($cacheid)) {
        return $cached;
    }

    $categories = [];

    // Get user visible categories from Moodle.
    $allcategories = core_course_category::get_all();
    $excludecat = theme_mb2nl_course_excats();

    // Filter categories.
    foreach ($allcategories as $id => $category) {

        // Parent category.
        if (!is_null($parentid) && $category->parent != $parentid) {
            continue;
        }

        // Theme exclude categries.
        if (!empty($excludecat) && in_array($id, $excludecat)) {
            continue;
        }

        // Include only certain categories.
        if (!empty($opts['categories']) && !in_array($id, $opts['categories'])) {
            continue;
        }

        // Exclude categories.
        if (!empty($opts['excats']) && !empty($opts['catids'])) {
            $excludecats = array_map('trim', explode(',', $opts['catids']));
            if ($opts['excats'] === 'exclude' && in_array($id, $excludecats)) {
                continue;
            } else if ($opts['excats'] === 'include' && !in_array($id, $excludecats)) {
                continue;
            }
        }

        // Store either ID or object.
        $categories[$id] = $onlyid ? $id : $category;

    }

    // Apply pagination (if limit > 0).
    if ($catlimit > 0) {
        $categories = array_slice($categories, $catlimitfrom, $catlimit, true);
    }

    // Get courses count by category.
    $ccnt = [];

    if ($withcnt && !empty($categories) && !$onlyid) {

        $catids = array_keys($categories);

        // Get visible courses without caching.
        $visiblecourses = theme_mb2nl_visible_course_ids($catids, false);

        if (!empty($visiblecourses)) {
            list($coursesql, $courseparams) = $DB->get_in_or_equal($visiblecourses, SQL_PARAMS_NAMED, 'cid');

            $records = $DB->get_records_sql('SELECT category, COUNT(id) AS cnt FROM {course} WHERE id ' . $coursesql .
            ' GROUP BY category', $courseparams);

            foreach ($records as $r) {
                $ccnt[$r->category] = $r->cnt;
            }
        }

        foreach ($categories as $id => $category) {
            $catobj = new stdClass();
            $catobj->id = $id;
            $catobj->cat = $category;
            $catobj->parent = $category->parent;
            $catobj->visible = $category->visible;
            $catobj->name = $category->name;
            $catobj->coursecount = $withcnt ? ($ccnt[$id] ?? 0) : -1;
            $catobj->children = !empty($category->get_children());
            $categories[$id] = $catobj;
        }

    }

    // Set cache.
    $cache->set($cacheid, $categories);
    return $categories;

}






/**
 *
 * Method to get categories list
 *
 */
function theme_mb2nl_courses_filter_categories($urlcategory = 0, $parentid = 0) {

    $output = '';

    $output .= '<div class="filter-block">';
    $output .= '<input type="hidden" name="categories" value="">';
    // This is required for the pagination links if the categry in the tree is not loaded.
    if ($urlcategory) {
        $output .= '<input class="mb2filter-inpt" type="hidden" name="categories[]" value="' . $urlcategory . '">';
    }
    $output .= theme_mb2nl_courses_filter_heading(get_string('categories'));
    $output .= '<div id="cfilter_categories" class="filter-content filter-categories">';
    $output .= theme_mb2nl_categories_tree_html($urlcategory, $parentid);
    $output .= '</div>'; // ...filter-categories
    $output .= '</div>';

    return $output;

}




/**
 *
 * Method to get categories list
 *
 */
function theme_mb2nl_categories_tree_html_items($urlcategory = 0, $parentid = 0, $opts = []) {

    global $CFG;

    $output = '';
    $flexcls = theme_mb2nl_bsfcls(2, '', 'center', 'center');

    $copts = [
        'catlimit' => $CFG->coursesperpage,
        'parentid' => $parentid,
        'withcnt' => true,
    ];

    if (!empty($opts)) {
        $copts = $opts;
    }

    // Get filtered categories with course counts.
    // We need to get limited categories in the parent categry with courses count.
    $categories = theme_mb2nl_get_categories($copts);

    if (empty($categories)) {
        return;
    }

    foreach ($categories as $cat) {

        $loading = '';
        $coursescount = ' <span class="info">(' . $cat->coursecount . ')</span>';
        $hiddenicon = !$cat->visible ? ' <span class="hidden-icon"><span class="sr-only">' .
        get_string('hidden', 'theme_mb2nl') . '</span><i class="ri-eye-off-line"></i></span>' : '';

        $disabled = $cat->coursecount == 0 ? ' disabled' : '';
        $disabledcls = $disabled;

        $checked = '';

        if ($urlcategory > 0 && $urlcategory == $cat->id) {
            $checked = ' checked';
            $disabled = ' disabled';
        }

        if (!empty($cat->children) && !$cat->coursecount) {
            $coursescount = '';
            $disabledcls = ' disabled1';
        }

        if (!empty($cat->children)) {
            $loading = '<span class="item-spin d-none"></span>';
        }

        $output .= '<li class="filter-form-field">';
        $output .= '<div class="field-container' . $disabledcls . $disabled . '">';

        $output .= '<label for="catid_' . $cat->id . '">';
        $output .= '<input class="mb2filter-inpt" type="checkbox" id="catid_' . $cat->id . '" name="categories[]" value="' .
        $cat->id . '"' . $disabled . $checked . '>';
        $output .= '<span class="field-mark position-relative lhsmall' . $flexcls . '">
        <i class="bi bi-check' . $flexcls . '"></i></span>';
        $output .= theme_mb2nl_format_str($cat->name) . $hiddenicon . $coursescount . $loading;
        $output .= '</label>';

        $output .= !empty($cat->children) ?
        '<button type="button" class="toggle-list-btn themereset lhsmall' . $flexcls . '" aria-expanded="false"
        aria-controls="childcat-' . $cat->id . '" data-catid="' . $cat->id . '">
            <span class="sr-only">' . get_string('togglecategory', 'theme_mb2nl', theme_mb2nl_format_str($cat->name)) . '</span>
            <i class="bi bi-chevron-right" aria-hidden="true"></i>
        </button>' : '';

        $output .= '</div>';

        // Children category here.

        $output .= '</li>';
    }

    return $output;

}




/**
 *
 * Method to get categories list
 *
 */
function theme_mb2nl_categories_tree_html($urlcategory, $parentid) {

    global $CFG;

    $listcls = '';
    $listcls .= ' toggle-list';

    $copts = [
        'onlyid' => 1,
        'parentid' => $parentid,
        'withcnt' => false,
    ];

    // Get filtered categories visible to the user.
    // We need to get all categories in the parent category.
    $cacount = count(theme_mb2nl_get_categories($copts));

    $output = '<ul id="childcat-' . $parentid . '" class="filter-categories-list' . $listcls . '">';

    $output .= theme_mb2nl_categories_tree_html_items($urlcategory, $parentid);

    if ($CFG->coursesperpage < $cacount) {
        $output .= '<li>' . theme_mb2nl_categories_loadmore('category', $parentid, $cacount) . '</li>';
    }

    $output .= '</ul>';

    return $output;

}


/**
 *
 * Method to get categories list
 *
 */
function theme_mb2nl_categories_loadmore($type, $catid, $cacount) {

    global $CFG;

    $output = '';
    $perpage = $CFG->coursesperpage;
    $flexcls = theme_mb2nl_bsfcls(2, '', 'center', 'center');

    $output .= '<div class="catloadmore-wrap' . theme_mb2nl_bsfcls(1, 'column', 'center') . '">';
    $output .= '<button class="catloadmore' . $flexcls . '" type="button" data-type="' . $type . '" data-catid="' . $catid .'"';
    $output .= ' data-page="1" data-perpage="' . $perpage . '" data-cacount="' . $cacount . '">';
    $output .= '<span class="btntext' . $flexcls . '">' . get_string('loadmorecats', 'theme_mb2nl');
    $output .= ' (<span class="info">' . get_string('showingcats', 'theme_mb2nl', ['x' => $perpage, 'y' => $cacount]) . '</span>)';
    $output .= '<span class="item-spin' . $flexcls . '"></span>';
    $output .= '</span>';
    $output .= '</button>';
    $output .= '</div>';

    return $output;

}





/**
 *
 * Method to get categories list
 *
 */
function theme_mb2nl_courses_filter_heading($str) {

    $output = '';

    $output .= '<div class="filter-heading mb-3' . theme_mb2nl_bsfcls(1, '', 'between', 'center') . '">';
    $output .= '<h4 class="filter-title h6 mb-0">' . theme_mb2nl_format_str($str) . '</h4>';
    $output .= '</div>'; // ...filter-heading

    return $output;

}





/**
 *
 * Method to set categories options
 *
 */
function theme_mb2nl_tags_startopts($options) {

    $startopts = [];
    $opt2set = [
        'tags' => [],
        'taglimit' => 0,
        'taglimitfrom' => 0,
        'extags' => '',
        'tagids' => '',
        'count' => 0,
    ];

    foreach ($opt2set as $key => $default) {

        if (!isset($options[$key])) {
            $startopts[$key] = $default;
            continue;
        }

        $value = $options[$key];

        // Only normalize fields that are defined as arrays in defaults.
        if (is_array($default)) {

            if (!is_array($value)) {
                $value = explode(',', (string)$value);
            }

            // Convert all values to string.
            $value = array_map('strval', $value);
        }

        $startopts[$key] = $value;

    }

    ksort($startopts);

    return $startopts;

}




/**
 *
 * Method to get course tags
 *
 */
function theme_mb2nl_course_tags($opts = [], $fields='t.id,t.name,t.rawname') {

    global $DB, $PAGE, $USER;

    $limitfrom = $opts['taglimitfrom'] ?? 0;
    $limitnum  = $opts['taglimit'] ?? 0;
    $count = (isset($opts['count']) && $opts['count'] == 1);

    // Check for cache.
    ksort($opts);
    $cache = cache::make('theme_mb2nl', 'coursetags');
    $cacheid = ($count ? 'ctco_' : 'ctli_') . $USER->id . '_' . md5(json_encode(theme_mb2nl_tags_startopts($opts)));

    if ($cached = $cache->get($cacheid)) {
        return $cached;
    }

    $params = [];
    $sqlwhere = ' WHERE 1=1';
    $basesql = ' FROM {tag} t JOIN {tag_instance} ti ON ti.tagid = t.id JOIN {course} c ON c.id = ti.itemid';

    $sqlwhere .= ' AND ti.itemtype=?';
    $params[] = 'course';

    // Check for visible categories and courses.
    // We need to get all categories. The categories are cached before in the list of courses.
    $visiblecats = theme_mb2nl_get_categories(['onlyid' => 1]);
    $visiblecourses = theme_mb2nl_visible_course_ids($visiblecats);

    // Filter for visible courses.
    if (!empty($visiblecourses)) {
        list($canseecoursesql, $canseecourseparams) = $DB->get_in_or_equal($visiblecourses);
        $params = array_merge($params, $canseecourseparams);
        $sqlwhere .= ' AND c.id ' . $canseecoursesql;
    } else {
        if ($count) {
            $cache->set($cacheid, 0);
            return 0;
        } else {
            $cache->set($cacheid, []);
            return [];
        }
    }

    // Exclude tags filter.
    $extags = theme_mb2nl_course_extags();

    if ($extags[0]) {
        $isnotags = count($extags) > 1 ? 'NOT ' : '!';
        list($extagnsql, $extagparams) = $DB->get_in_or_equal($extags);
        $params = array_merge($params, $extagparams);

        $sqlwhere .= ' AND t.id ' . $isnotags . $extagnsql;
    }

    // Custom exclude categories.
    // Require for coursetabs shortcode.
    if ((isset($opts['extags']) && isset($opts['tagids'])) && $opts['extags'] && $opts['tagids']) {
        $isnot = '';
        $excludetag2 = explode(',', $opts['tagids']);
        $excludetag2 = array_map('trim', $excludetag2);

        if ($opts['extags'] === 'exclude') {
            $isnot = count($excludetag2) > 1 ? 'NOT ' : '!';
        }

        list($extaginsql2, $extagparams2) = $DB->get_in_or_equal($excludetag2);
        $params = array_merge($params, $extagparams2);
        $sqlwhere .= ' AND t.id ' . $isnot . $extaginsql2;
    }

    // Tgas of expired courses.
    if (!theme_mb2nl_theme_setting($PAGE, 'expiredcourses')) {
        $sqlwhere .= ' AND (c.enddate=? OR c.enddate>?)';
        $params[] = 0;
        $params[] = theme_mb2nl_get_user_date();
    }

    // Count tags.
    if ($count) {
        $countsql = 'SELECT COUNT(DISTINCT t.id) ' . $basesql . $sqlwhere;
        $tcount = $DB->count_records_sql($countsql, $params);
        $cache->set($cacheid, $tcount);
        return $tcount;
    }

    // Build INNER query (DISTINCT applied here).
    $innersql = 'SELECT DISTINCT ' . $fields . $basesql . $sqlwhere;

    // Wrap with outer query to safely apply ORDER + LIMIT.
    $sql = 'SELECT * FROM (' . $innersql . ') tagsub ORDER BY name ASC';

    // Retun tags.
    $tags = $DB->get_records_sql($sql, $params, $limitfrom, $limitnum);
    $cache->set($cacheid, $tags);
    return $tags;

}


/**
 *
 * Method to get course tag IDs
 *
 */
function theme_mb2nl_course_tag_ids($opts = []) {

    $tags = theme_mb2nl_course_tags($opts);
    $ids = [];

    if (!count($tags)) {
        return [];
    }

    foreach ($tags as $tag) {
        $ids[] = $tag->id;
    }

    return $ids;

}











/**
 *
 * Method to get courses count by tag
 *
 */
function theme_mb2nl_get_tags_course_count($tagid, $opt = []) {

    global $DB, $PAGE, $USER;

    // Check for cache.
    ksort($opt);
    $cache = cache::make('theme_mb2nl', 'coursetags');
    $cacheid = 'ctagsc_' . $tagid . '_' . $USER->id . '_' . md5(json_encode($opt));

    if ($cached = $cache->get($cacheid)) {
        return $cached;
    }

    $params = [];

    $sqlquery = 'SELECT COUNT(DISTINCT c.id) FROM {course} c JOIN {context} cx ON cx.instanceid=c.id JOIN {tag_instance} ti';
    $sqlquery .= ' ON ti.contextid=cx.id WHERE cx.contextlevel=' . CONTEXT_COURSE;

    // This condition is required for the 'All' course tab.
    if ($tagid) {
        $sqlquery .= ' AND ti.tagid=' . $tagid;
    }

    // Check for visible categories and courses.
    $visiblecats = theme_mb2nl_get_categories(['onlyid' => 1]);
    $visiblecourses = theme_mb2nl_visible_course_ids($visiblecats);

    // Filter hidden categories.
    if (!empty($visiblecats)) {
        list($canseecatsql, $canseecatparams) = $DB->get_in_or_equal($visiblecats);
        $params = array_merge($params, $canseecatparams);
        $sqlquery .= ' AND c.category ' . $canseecatsql;
    }

    // Filter for visible courses.
    if (!empty($visiblecourses)) {
        list($canseecoursesql, $canseecourseparams) = $DB->get_in_or_equal($visiblecourses);
        $params = array_merge($params, $canseecourseparams);
        $sqlquery .= ' AND c.id ' . $canseecoursesql;
    } else {
        $cache->set($cacheid, 0);
        return 0;
    }

    // Exclude expired courses.
    if (!theme_mb2nl_theme_setting($PAGE, 'expiredcourses')) {
        $params[] = theme_mb2nl_get_user_date();
        $sqlquery .= ' AND (c.enddate=0 OR c.enddate>?)';
    }

    // Exclude tags.
    $extags = theme_mb2nl_course_extags();
    if ($extags[0]) {
        $isnotags = count($extags) > 1 ? 'NOT ' : '!';
        list($extaginsql, $extagparams) = $DB->get_in_or_equal($extags);
        $params = array_merge($params, $extagparams);

        $sqlquery .= ' AND NOT EXISTS(SELECT DISTINCT t.id FROM {tag} t JOIN {tag_instance} ti ON ti.tagid=t.id JOIN {context} cx';
        $sqlquery .= ' ON cx.id=ti.contextid WHERE c.id=cx.instanceid';
        $sqlquery .= ' AND cx.contextlevel = ' . CONTEXT_COURSE;
        $sqlquery .= ' AND t.id ' . $extaginsql;
        $sqlquery .= ')';
    }

    // Exclude categories.
    if (isset($opt['catids'], $opt['excats']) &&  $opt['catids'] && $opt['excats']) {
        $isnot = '';
        $opt['catids'] = explode(',', $opt['catids']);

        if ($opt['excats'] === 'exclude') {
            $isnot = count($opt['catids']) > 1 ? 'NOT ' : '!';
        }

        list($excatinsql, $excatparams) = $DB->get_in_or_equal($opt['catids']);
        $params = array_merge($params, $excatparams);
        $sqlquery .= ' AND c.category ' . $isnot . $excatinsql;
    }

    // Filter tags for shortcodes. This is require for the "All" course tab.
    if (isset($opt['tagids'], $opt['extags']) && $opt['tagids'] && $opt['extags']) {
        $isnot = '';

        $tagsarr = explode(',', $opt['tagids']);

        if ($opt['extags'] === 'exclude') {
            $isnot = 'NOT ';
        }

        list($extaginsql, $extagparams) = $DB->get_in_or_equal($tagsarr);
        $params = array_merge($params, $extagparams);

        $sqlquery .= ' AND ' . $isnot. 'EXISTS(SELECT DISTINCT t.id FROM {tag} t JOIN {tag_instance} ti ON ti.tagid=t.id';
        $sqlquery .= ' JOIN {context} cx ON cx.id=ti.contextid WHERE c.id=cx.instanceid';
        $sqlquery .= ' AND cx.contextlevel = ' . CONTEXT_COURSE;
        $sqlquery .= ' AND t.id ' . $extaginsql;
        $sqlquery .= ')';
    }

    $count = $DB->count_records_sql($sqlquery, $params);
    $cache->set($cacheid, $count);

    return $count;

}





/**
 *
 * Method to get courses exlude tags
 *
 */
function theme_mb2nl_course_extags() {
    global $PAGE;

    $exctags = theme_mb2nl_theme_setting($PAGE, 'exctags');
    return explode(',', $exctags);

}






/**
 *
 * Method to get set start options for courses page
 *
 */
function theme_mb2nl_teachers_startopts($options) {

    $startopts = [];
    $opt2set = [
        'limit' => 0,
        'limitfrom' => 0,
        'fields' => 'u.id,u.firstname,u.lastname',
        'count' => 0,
    ];

    foreach ($opt2set as $key => $default) {

        if (!isset($options[$key])) {
            $startopts[$key] = $default;
            continue;
        }

        $value = $options[$key];

        // Only normalize fields that are defined as arrays in defaults.
        if (is_array($default)) {

            if (!is_array($value)) {
                $value = explode(',', (string)$value);
            }

            // Convert all values to string.
            $value = array_map('strval', $value);
        }

        $startopts[$key] = $value;

    }

    ksort($startopts);

    return $startopts;

}






/**
 *
 * Method to get all teachers
 *
 */
function theme_mb2nl_get_all_teachers($opts = []) {

    global $DB, $USER;

    $count = isset($opts['count']) ? $opts['count'] : 0;
    $limit = isset($opts['limit']) ? $opts['limit'] : 0;
    $limitfrom = isset($opts['limitfrom']) ? $opts['limitfrom'] : 0;
    $fields = isset($opts['fields']) ? $opts['fields'] : 'u.id,u.firstname,u.lastname';

    // Step 1: Get all visible categories.
    $opts['onlyid'] = 1;
    $visiblecats = theme_mb2nl_get_categories($opts);
    if (empty($visiblecats)) {
        if ($count) {
            return 0;
        } else {
            return [];
        }
    }

    // Step 2: Get all courses the user can see (visible + allowed hidden).
    $visiblecourses = theme_mb2nl_visible_course_ids($visiblecats);
    if (empty($visiblecourses)) {
        if ($count) {
            return 0;
        } else {
            return [];
        }
    }

    // Step 3: Prepare cache.
    $cache = cache::make('theme_mb2nl', 'userroles');
    $cacheid = 'tealist_' . $USER->id . '_' . md5(json_encode(theme_mb2nl_teachers_startopts($opts)));

    if ($cached = $cache->get($cacheid)) {
        return $cached;
    }

    // Step 4: Teacher role.
    $teacherroleid = theme_mb2nl_user_roleid(true);

    $sqlwhere = '';
    $params = [];
    $params['roleid'] = $teacherroleid;
    $params['contextlevel'] = CONTEXT_COURSE;

    // Do not include deleted or suspended users.
    $sqlwhere .= ' AND u.deleted=0';
    $sqlwhere .= ' AND u.suspended=0';

    // Step 5: Restrict to visible courses using EXISTS.
    list($coursesql, $courseparams) = $DB->get_in_or_equal($visiblecourses, SQL_PARAMS_NAMED, 'c');
    $params = array_merge($params, $courseparams);

    $sqlwhere .= ' AND EXISTS (SELECT 1 FROM {role_assignments} ra JOIN {context} cx ON ra.contextid = cx.id';
    $sqlwhere .= ' WHERE ra.userid = u.id AND ra.roleid = :roleid AND cx.contextlevel = :contextlevel';
    $sqlwhere .= 'AND cx.instanceid ' . $coursesql . ')';

    // Include / exclude specific teachers.
    if (isset($opts['teacherids']) && $opts['teacherids'] && $opts['exteachers']) {
        $isnot = '';

        // Split and cast teacher IDs to integers.
        $teacherids = array_map('intval', explode(',', $opts['teacherids']));

        if ($opts['exteachers'] === 'exclude') {
            $isnot = count($teacherids) > 1 ? 'NOT ' : '!';
        }

        // Use named parameters to avoid mixed types.
        list($teachersql, $teacherparams) = $DB->get_in_or_equal($teacherids, SQL_PARAMS_NAMED, 't');

        // Merge with existing $params (all keys are strings).
        $params = array_merge($params, $teacherparams);
        $sqlwhere .= ' AND u.id ' . $isnot . $teachersql;
    }

    if ($count) {
        $recordsqlcount = 'SELECT COUNT(DISTINCT u.id) FROM {user} u WHERE 1=1' . $sqlwhere;
        $teacherscount = $DB->count_records_sql($recordsqlcount, $params);

        // Set cache.
        $cache->set($cacheid, $teacherscount);
        return $teacherscount;
    }

    $sqlorder = ' ORDER BY u.lastname';
    $recordsql = 'SELECT DISTINCT ' . $fields . ' FROM {user} u WHERE 1=1' . $sqlwhere . $sqlorder;
    $teachers = $DB->get_records_sql($recordsql, $params, $limitfrom, $limit);

    // Set cache.
    $cache->set($cacheid, $teachers);
    return $teachers;

}








/**
 *
 * Method to get course list.
 *
 */
function theme_mb2nl_course_list($opt = []) {

    global $CFG;
    $output = '';
    $coursesnum = theme_mb2nl_get_courses($opt, true);

    $output .= '<div class="theme-courses-list" data-page="' . $opt['page'] . '">';

    if (!$coursesnum) {
        $output .= '<div class="theme-course-item nothingtodisplay">' . get_string('nothingtodisplay') . '</div>';
    } else {
        $courses = theme_mb2nl_get_courses($opt);
        $output .= theme_mb2nl_course_list_courses($courses, false, $opt);
    }

    $output .= '</div>'; // ...theme-courses-list

    $output .= theme_mb2nl_course_list_pagin($coursesnum, $CFG->coursesperpage, $opt);

    return $output;

}




/**
 *
 * Method to course list.
 *
 */
function theme_mb2nl_course_list_courses($courses, $box = false, $options = []) {
    global $CFG, $PAGE;
    $output = '';
    $reviewplugin = theme_mb2nl_is_review_plugin();
    $quickview = theme_mb2nl_theme_setting($PAGE, 'quickview');
    $rating = '';
    $carousel = (isset($options['carousel']) && $options['carousel']);
    $carouselcls = $carousel ? ' swiper-slide' : '';

    $lazycls = $options['lazy'] && !$carousel ? ' class="lazy"' : '';
    $lazysrc = $options['lazy'] && !$carousel ? 'src="' . theme_mb2nl_lazy_plc(true) . '" data-src' : 'src';
    $swiperlazy = $carousel ? ' loading="lazy"' : '';
    $swiperpreload = $carousel ? theme_mb2nl_swiper_lazy_plc() : '';

    $htag = isset($options['htag']) ? $options['htag'] : 'h3';

    // For better speed use require.
    if ($reviewplugin && !class_exists('Mb2reviewsHelper')) {
        require($CFG->dirroot . '/local/mb2reviews/classes/helper.php');
    }

    // Item css classess.
    $cls = theme_mb2nl_citem_cls($box, $options);

    if (!count($courses)) {
        $output .= '<div class="theme-box">';
        $output .= get_string('nothingtodisplay');
        $output .= '</div>';
        return $output;
    }

    foreach ($courses as $course) {
        $courselink = new moodle_url('/course/view.php', ['id' => $course->id]);
        $price = theme_mb2nl_course_price_html($course->id);

        // Course item style.
        $itemstyle = ' style="';
        $itemstyle .= theme_mb2nl_cat_color_itemattr($course);
        $itemstyle .= '--mb2-crandpct:' . rand(20, 80) . '%;';
        $itemstyle .= '"';

        $hiddenicon = !$course->visible ? ' <span class="hidden-icon"><span class="sr-only">' . get_string('hidden', 'theme_mb2nl')
        . '</span><i class="ri-eye-off-line"></i></span>' : '';

        $cname = theme_mb2nl_format_str($course->fullname);

        $catcls = ' cat-' . $course->category;
        $pricecls = $price ? ' isprice' : ' noprice';

        $coursecontext = context_course::instance($course->id);
        $bestseller = theme_mb2nl_is_bestseller($coursecontext->id, $course->category);
        $bestcls = $bestseller ? ' bestseller' : '';

        $output .= '<div class="theme-course-item course-' . $course->id . $cls . $catcls . $bestcls . $pricecls . $carouselcls
        . '" data-course="' . $course->id . '" data-custom_label="' . strip_tags($cname) . '" role="presentation">';
        $output .= '<div class="theme-course-item-inner position-relative"' . $itemstyle . '>';

        $output .= '<div class="image-wrap">';

        $output .= '<div class="image">';
        $output .= theme_mb2nl_course_badges($course);
        $output .= '<img' . $swiperlazy . $lazycls . ' ' . $lazysrc . '="' . theme_mb2nl_course_image_url($course->id, true) .
        '" alt="' . $cname . '">' . $swiperpreload;
        $output .= '</div>'; // ...image

        if (!$quickview) {
            $output .= '<div class="image-content position-absolute' . theme_mb2nl_bsfcls(1, '', 'center', 'center') .
            '" aria-hidden="true">';
            $output .= '<span class="mb2-pb-btn rounded1">' . get_string('view') . '</span>';
            $output .= '</div>'; // ...image-content
        } else {
            $output .= '<button type="button" class="qw-launcher themereset position-absolute tsizesmall lhsmall" tabindex="-1">
            <i class="bi bi-eye" aria-hidden="true"></i> ' . get_string('quickviewfe', 'theme_mb2nl') . '</button>';
        }

        $output .= '</div>'; // ...image-wrap

        $output .= '<div class="content-wrap position-relative">';

        $output .= '<div class="course-content">';

        $output .= '<'. $htag . ' class="title h5 mb-0">';
        $output .= '<a class="d-block" href="' . $courselink . '">' . $cname . $hiddenicon . '</a>';
        $output .= '</'. $htag . '>';

        $output .= '<div class="course-item-deatils tsizesmall lhsmall mt-2' . theme_mb2nl_bsfcls(1, 'wrap', '', 'center') . '">';
        $output .= theme_mb2nl_course_list_catname($course);
        $output .= theme_mb2nl_course_teachers($course->id);
        $output .= '</div>';

        if ($reviewplugin) {
            $ratingobj = theme_mb2nl_review_obj($course->id);

            if ($ratingobj->rating) {
                $output .= '<div class="course-rating mt-2">';
                $output .= '<span class="ratingnum">' . $ratingobj->rating . '</span>';
                $output .= Mb2reviewsHelper::rating_stars($ratingobj->rating, 'sm');
                $output .= '<span class="ratingcount">(' . $ratingobj->rating_count . ')</span>';
                $output .= '</div>'; // ...course-rating
            }
        }

        if (theme_mb2nl_theme_setting($PAGE, 'cdesc')) {
            $output .= '<div class="course-desc mt-3 pb-1">';
            $output .= theme_mb2nl_course_intro($course);
            $output .= '</div>'; // ...course-desc
        }

        $output .= '</div>'; // ...course-content

        $output .= '<div class="course-footer mt-3 pb-2' . theme_mb2nl_bsfcls(1, 'wrap', '', 'center') . '">';
        $output .= $price;
        $output .= theme_mb2nl_course_list_students($course->id);
        $output .= theme_mb2nl_course_list_date($course);
        $output .= '</div>'; // ...course-content

        $output .= '</div>'; // ...content-wrap
        $output .= $courselink ? '<a class="linkabs" href="' . $courselink . '" tabindex="-1"><span class="sr-only">' . $cname
        . '</span></a>' : '';
        $output .= '</div>'; // ...theme-course-item-inner
        $output .= '</div>'; // ...theme-course-item
    }

    return $output;

}







/**
 *
 * Method to set course list pagination.
 *
 */
function theme_mb2nl_course_list_pagin($items, $limit, $opt) {
    $output = '';

    $numpagesround = round($items / $limit, 1);
    $numpages = ceil($numpagesround);
    $endscount = 1;
    $middlecount = 2;
    $dots = false;

    if ($numpages < 2) {
        return;
    }

    $output .= '<div class="theme-courses-pagin">';
    $output .= '<ul class="theme-courses-pagin-list fwmedium' . theme_mb2nl_bsfcls(1, '', 'center', 'center') . '">';

    // Set previous button.
    if ($opt['page'] > 1) {
        $output .= '<li>';
        $output .= '<button type="button" class="theme-courses-paginitem themereset lhsmall p-0' .
        theme_mb2nl_bsfcls(2, '', 'center', 'center') . '" aria-label="' . get_string('previouspage') . '" data-page="' .
        ($opt['page'] - 1) . '">';
        $output .= '<i class="bi bi-arrow-left-short"></i>';
        $output .= '</button>';
        $output .= '</li>';
    }

    for ($i = 1; $i <= $numpages; $i++) {
        if ($i == $opt['page']) {
            $output .= '<li>';
            $output .= '<button type="button" class="theme-courses-paginitem active themereset lhsmall p-0' .
            theme_mb2nl_bsfcls(2, '', 'center', 'center') . '" data-page="' . $i . '" aria-label="' .
            get_string('pagedcontentnavigationactiveitem', 'moodle', $i) . '">' . $i;
            $output .= '</button>';
            $output .= '</li>';
            $dots = true;
        } else {
            if ($i <= $endscount || ($opt['page'] && $i >= ($opt['page'] - $middlecount) && $i <= ($opt['page'] + $middlecount))
            || $i > $numpages - $endscount) {
                $output .= '<li>';
                $output .= '<button type="button" class="theme-courses-paginitem themereset lhsmall p-0' .
                theme_mb2nl_bsfcls(2, '', 'center', 'center') . '" data-page="' . $i . '" aria-label="' .
                get_string('pagea', 'moodle', $i) . '">' . $i;
                $output .= '</button>';
                $output .= '</li>';
                $dots = true;
            } else if ($dots) {
                $output .= '<li><button type="button" class="dots themereset lhsmall p-0' .
                theme_mb2nl_bsfcls(2, '', 'center', 'center') . '">&#183;&#183;&#183;</button></li>';
                $dots = false;
            }
        }
    }

    // Set next button.
    if ($opt['page'] < $numpages) {
        $output .= '<li>';
        $output .= '<button type="button" class="theme-courses-paginitem themereset lhsmall p-0' .
        theme_mb2nl_bsfcls(2, '', 'center', 'center') . '" aria-label="' . get_string('nextpage') . '" data-page="' .
        ($opt['page'] + 1) . '">';
        $output .= '<i class="bi bi-arrow-right-short"></i>';
        $output .= '</button>';
        $output .= '</li>';
    }

    $output .= '</ul>';
    $output .= '</div>';

    return $output;

}





/**
 *
 * Method to set course top bar.
 *
 */
function theme_mb2nl_course_top_bar() {
    global $PAGE;

    $output = '';
    $cls = ' filterpos' . theme_mb2nl_courses_filterpos();

    $output .= '<div class="theme-courses-topbar' . $cls . theme_mb2nl_bsfcls(1, '', '', 'center') . '">';
    $output .= theme_mb2nl_course_filtertoggle();
    $output .= theme_mb2nl_course_clearfilters();
    $output .= theme_mb2nl_course_searchform();
    $output .= '</div>';

    return $output;

}



/**
 *
 * Method to set clear filters button.
 *
 */
function theme_mb2nl_course_clearfilters() {
    global $CFG, $PAGE;

    $output = '';
    $urlopts = theme_mb2nl_course_urlopts();
    $str = $CFG->version < 2022112800 ? get_string('clearfilters', 'theme_mb2nl') : get_string('clearfilters');
    $cls = '';
    $tagstart = '<button type="button" class="themereset';
    $tagend = '</button>';

    if (!empty($urlopts)) {
        $cls = ' go2courses';
        $tagstart = '<a href="' . new moodle_url('/course/index.php') . '" class="';
        $tagend = '</a >';
    }

    $output .= $tagstart . ' clearfilters mb2-hidden p-0 mb2mr-auto mb2ml-3' .
    theme_mb2nl_bsfcls(2, '', '', 'center') . $cls . '" aria-controls="cfilter_wrap" aria-expanded="false" aria-label="'.$str .'">';
    $output .= '<span class="text fwmedium lhsmall">' . $str . '</span>';
    $output .= $tagend;

    return $output;

}


/**
 *
 * Method to set course search form.
 *
 */
function theme_mb2nl_course_filtertoggle() {
    global $PAGE;

    $output = '';

    if (!theme_mb2nl_is_course_filters()) {
        return;
    }

    $output .= '<button type="button" class="themereset filter-toggle p-0 fpos-' . theme_mb2nl_courses_filterpos() .
    theme_mb2nl_bsfcls(2, '', '', 'center') . '" aria-controls="cfilter_wrap" aria-expanded="false" aria-label="' .
    get_string('filters') . '">';
    $output .= '<i class="ri-equalizer-line' . theme_mb2nl_bsfcls(2, '', '', 'center') . '"></i>';
    $output .= '<span class="text mb2ml-2"> ' . get_string('filters') . '</span>';
    $output .= '</button>';

    return $output;

}





/**
 *
 * Method to set course search form.
 *
 */
function theme_mb2nl_course_searchform() {
    $output = '';
    $uniqid = uniqid('csearch_');

    $output .= '<form id="form_' . $uniqid . '" class="theme-course-search" action="index.php" method="GET">';
    $output .= '<div class="search-field' . theme_mb2nl_bsfcls(2, '', '', 'center') . '">';
    $output .= '<input id="' . $uniqid . '" name="' . $uniqid . '" type="search" value="" placeholder="' .
    get_string('searchcourses') . '">';
    $output .= '<button type="submit" aria-label="' . get_string('searchcourses') . '"><i class="ri-search-line"></i></button>';
    $output .= '</div>';
    $output .= '</form>';

    return $output;

}





/**
 *
 * Method to get count courses by custom fileds
 *
 */
function theme_mb2nl_get_cfileds_courses_count($fid, $v) {
    global $DB, $PAGE, $SITE, $USER;

    $cache = cache::make('theme_mb2nl', 'coursefields');
    $cacheid = 'cfieldcc_' . $USER->id . '_' . $fid . '_' . $v;

    // If ther is cache, return it.
    if ($cached = $cache->get($cacheid)) {
        return $cached;
    }

    $params = [];
    $sqlquery = '';
    $sqlwhere = ' WHERE 1=1';

    $anddate = '';
    $isnot = $v == 0 ? '!=' : '='; // It is required for the 'All" radio filed type.

    // Check expired courses.
    if (!theme_mb2nl_theme_setting($PAGE, 'expiredcourses')) {
        $anddate = ' AND (c.enddate=0 OR c.enddate>' . theme_mb2nl_get_user_date() . ')';
    }

    // Check for visible categories and courses.
    $visiblecats = theme_mb2nl_get_categories(['onlyid' => 1]);
    $visiblecourses = theme_mb2nl_visible_course_ids($visiblecats);

    // Filter hidden categories.
    if (!empty($visiblecats)) {
        list($canseecatsql, $canseecatparams) = $DB->get_in_or_equal($visiblecats);
        $params = array_merge($params, $canseecatparams);
        $hiddencats = ' AND c.category ' . $canseecatsql;
    }

    // Filter for visible courses.
    if (!empty($visiblecourses)) {
        list($canseecoursesql, $canseecourseparams) = $DB->get_in_or_equal($visiblecourses);
        $params = array_merge($params, $canseecourseparams);
        $hiddencourses = ' AND c.id ' . $canseecoursesql;
    } else {
        $cache->set($cacheid, 0);
        return 0;
    }

    $sqlquery = 'SELECT COUNT(c.id) FROM {course} c';

    $sqlwhere .= ' AND c.id !=' . $SITE->id;
    $sqlwhere .= $hiddencats;
    $sqlwhere .= $hiddencourses;
    $sqlwhere .= $anddate;

    $sqlwhere .= ' AND EXISTS(SELECT cf.id, cf.fieldid FROM {customfield_data} cf JOIN {context} cx ON cx.id=cf.contextid';
    $sqlwhere .= ' WHERE c.id=cx.instanceid';
    $sqlwhere .= ' AND cx.contextlevel=' . CONTEXT_COURSE;
    $sqlwhere .= ' AND cf.fieldid=' . $fid;
    $sqlwhere .= ' AND cf.value' . $isnot . $v;
    $sqlwhere .= ')';

    $count = $DB->count_records_sql($sqlquery . $sqlwhere, $params);
    $cache->set($cacheid, $count);

    return $count;

}






/**
 *
 * Method to get count courses (paid and free).
 *
 */
function theme_mb2nl_get_paid_courses_count() {
    global $DB, $PAGE, $USER;

    // Get cache.
    $cache = cache::make('theme_mb2nl', 'courses');
    $cacheid = 'paidcc_' . $USER->id;

    if ($cached = $cache->get($cacheid)) {
        return $cached;
    }

    $params = [];
    $anddate = '';

    // Payment filter.
    list($priceinsql, $priceparams) = $DB->get_in_or_equal(theme_mb2nl_pay_enrolements());
    $params = array_merge($params, $priceparams);

    // Check expired courses.
    if (!theme_mb2nl_theme_setting($PAGE, 'expiredcourses')) {
        $anddate = ' AND (c.enddate=0 OR c.enddate>' . theme_mb2nl_get_user_date() . ')';
    }

    $sqlquery = 'SELECT COUNT(c.id) FROM {course} c WHERE EXISTS(SELECT er.id FROM {enrol} er WHERE er.courseid = c.id';
    $sqlquery .= ' AND er.status = ' . ENROL_INSTANCE_ENABLED . ' AND er.enrol ' . $priceinsql .') AND c.id > 1' . $anddate;

    // Exclude tags.
    $extags = theme_mb2nl_course_extags();
    if ($extags[0]) {
        $isnotags = count($extags) > 1 ? 'NOT ' : '!';
        list($extaginsql, $extagparams) = $DB->get_in_or_equal($extags);
        $params = array_merge($params, $extagparams);

        $sqlquery .= ' AND NOT EXISTS(SELECT DISTINCT t.id FROM {tag} t JOIN {tag_instance} ti ON ti.tagid=t.id JOIN {context} cx';
        $sqlquery .= ' ON cx.id=ti.contextid WHERE c.id=cx.instanceid';
        $sqlquery .= ' AND cx.contextlevel = ' . CONTEXT_COURSE;
        $sqlquery .= ' AND t.id ' . $extaginsql;
        $sqlquery .= ')';
    }

    // Check for visible categories and courses.
    $visiblecats = theme_mb2nl_get_categories(['onlyid' => 1]);
    $visiblecourses = theme_mb2nl_visible_course_ids($visiblecats);

    // Filter hidden categories.
    if (!empty($visiblecats)) {
        list($canseecatsql, $canseecatparams) = $DB->get_in_or_equal($visiblecats);
        $sqlquery .= ' AND c.category ' . $canseecatsql;
        $params = array_merge($params, $canseecatparams);
    }

    // Filter for visible courses.
    if (!empty($visiblecourses)) {
        list($canseecoursesql, $canseecourseparams) = $DB->get_in_or_equal($visiblecourses);
        $sqlquery .= ' AND c.id ' . $canseecoursesql;
        $params = array_merge($params, $canseecourseparams);
    } else {
        $cache->set($cacheid, 0);
        return 0;
    }

    $count = $DB->count_records_sql($sqlquery, $params);
    $cache->set($cacheid, $count);
    return $count;

}



/**
 *
 * Method to get courses exlude categories
 *
 */
function theme_mb2nl_course_excats() {

    global $PAGE;

    $cats = [];

    $excludecat = theme_mb2nl_theme_setting($PAGE, 'excludecat');

    if ($excludecat) {
        $cats = array_map('trim', explode(',', $excludecat));
        $cats = array_map('intval', $cats); // ...ensure numeric IDs
    }

    return $cats;

}




/**
 *
 * Method to get courses list layout.
 *
 */
function theme_mb2nl_course_urlopts() {

    $urlopts = [];

    $categoryid = optional_param('categoryid', 0, PARAM_INT);
    $tagid = optional_param('tagid', '', PARAM_RAW);
    $teacherid = optional_param('teacherid', '', PARAM_RAW);

    if ($categoryid) {
        $urlopts['categories'] = [$categoryid];
    }

    if ($tagid) {
        $urlopts['tags'] = explode('|', $tagid);
    }

    if ($teacherid) {
        $urlopts['instructors'] = explode('|', $teacherid);
    }

    if ($cfileds = theme_mb2nl_cfileds_for_data_att(false)) {
        $urlopts['cfields'] = [];
        foreach ($cfileds as $shortname => $value) {

            // Check if custom filed exixts.
            $field = theme_mb2nl_is_selectfield($shortname, $cfileds);

            if (!$field) {
                continue;
            }

            $urlopts['cfields'][$field->id] = explode('|', $value);
        }
    }

    return $urlopts;

}



/**
 *
 * Method to get courses list layout.
 *
 */
function theme_mb2nl_course_list_layout() {
    global $CFG, $PAGE;

    $output = '';

    $opts = theme_mb2nl_course_urlopts();
    $opts['page'] = 1;
    $opts['lazy'] = 0;
    $opts['htag'] = 'h2';
    $opts['perpage'] = $CFG->coursesperpage;
    $opts['limitfrom'] = 0;

    if (isset($opts['categories'])) {
        $output .= theme_mb2nl_children_categories($opts['categories']);
    }

    // Get cached courses.
    $cache = cache::make('theme_mb2nl', 'courses');
    $startopts = theme_mb2nl_courses_startopts($opts);
    $cacheid = theme_mb2nl_courses_cacheid($startopts);
    $iscache = $cache->has($cacheid);
    $wrapcls = !$iscache ? ' loading' : '';

    $output .= '<div class="courses-container">';
    $output .= theme_mb2nl_course_top_bar();
    $output .= theme_mb2nl_courses_filter_form(false);
    $output .= '<div class="courses-container-inner' . $wrapcls . '">';

    // Courses are cached, so return the list without AJAX loading.
    if ($iscache) {
        $output .= theme_mb2nl_course_list($opts, true);
    } else {
        // Courses are not cached, so set the placeholders and load courses via AJAX.
        $placesholders = theme_mb2nl_get_courses($opts, true);
        if ($placesholders > $opts['perpage']) {
            $placesholders = $opts['perpage'];
        }

        $output .= '<div class="theme-courses-list">';
        for ($i = 0; $i < $placesholders; $i++) {
            $output .= '<div class="theme-course-item theme-course-plchitem" aria-hidden="true"></div>';
        }
        $output .= '</div>';

        // Load course items with defaul options.
        $PAGE->requires->js_call_amd('theme_mb2nl/courselist', 'initCoursesPage', [$startopts]);
    }

    $output .= '</div>'; // Content loaded via js.
    $output .= '</div>'; // ...courses-container-inner

    // Set course list actions.
    $PAGE->requires->js_call_amd('theme_mb2nl/courselist', 'courseListActions');

    return $output;

}




/**
 *
 * Method to get children categories list layout.
 *
 */
function theme_mb2nl_children_categories($parent) {
    global $CFG;

    $output = '';
    $perpage = $CFG->coursesperpage;

    // Make sure the parent if is not [id].
    // This is to make stable category cache ID.
    $parent = is_array($parent) && !empty($parent) ? reset($parent) : $parent;

    $copts = [
        'catlimit' => $perpage,
        'parentid' => $parent,
        'withcnt' => true,
    ];

    $subcategories = theme_mb2nl_get_categories($copts);

    if (empty($subcategories)) {
        return;
    }

    // Get count of the filtered categories visible to the user.
    $cacount = count(theme_mb2nl_get_categories([
        'onlyid' => 1,
        'parentid' => $parent,
        'withcnt' => false,
    ]));

    $output .= '<div class="children-categories">';

    $output .= theme_mb2nl_children_categories_items($subcategories);

    if ($perpage < $cacount) {
        $output .= theme_mb2nl_categories_loadmore('category', $parent, $cacount);
    }

    $output .= '</div>';

    return $output;

}




/**
 *
 * Method to get children categories list layout.
 *
 */
function theme_mb2nl_children_categories_items($subcategories) {

    $output = '';
    $svg = theme_mb2nl_svg();

    foreach ($subcategories as $category) {
        $catlink = new moodle_url('/course/index.php', ['categoryid' => $category->id]);
        $catimgurl = theme_mb2nl_category_image($category->id);
        $catimg = $catimgurl ?
        '<img src="' . $catimgurl . '" alt="' . theme_mb2nl_format_str($category->name) . '">' : $svg['folder'];

        $output .= '<div class="children-category cat-' . $category->id . '">';
        $output .= '<a href="' . $catlink . '">';
        $output .= '<div class="cat-image">';
        $output .= $catimg;
        $output .= '</div>'; // ...cat-image
        $output .= '<div class="cat-content">';
        $output .= '<h4 class="children-cat-title">' . theme_mb2nl_format_str($category->name) . '</h4>';
        $output .= '<div class="children-category-details">';
        $output .= get_string('teachercourses', 'theme_mb2nl', ['courses' => $category->coursecount]);

        $output .= '</div>';
        $output .= '</div>'; // ...cat-content
        $output .= '</a>';
        $output .= '</div>';
    }

    return $output;

}







/**
 *
 * Method to check if ajax grid course is enabled
 *
 */
function theme_mb2nl_is_course_list() {
    global $PAGE;

    $coursegrid = theme_mb2nl_theme_setting($PAGE, 'coursegrid');

    if ($PAGE->pagetype !== 'course-index-category') {
        return;
    }

    return $coursegrid;

}



/**
 *
 * Method to get categories tabs
 *
 */
function theme_mb2nl_coursetabs_tabs($opts) {
    $i = 0;
    $output = '';
    $style = '';
    $allcoursecount = '';
    $cls = '';
    $cls .= isset($opts['tabstyle']) ? ' tabstyle' . $opts['tabstyle'] : '';
    $cls .= isset($opts['tcenter']) ? ' tcenter' . $opts['tcenter'] : '';

    $style .= ' style="';
    $style .= isset($opts['acccolor']) && $opts['acccolor'] ? '--mb2-pb-coursetabsacc:' . $opts['acccolor'] . ';' : '';
    $style .= isset($opts['tcolor']) && $opts['tcolor'] ? '--mb2-pb-coursetabsc:' . $opts['tcolor'] . ';' : '';
    $style .= '"';

    $taball = $opts['filtertype'] === 'category' ? $opts['taball'] && !$opts['catdesc'] : $opts['taball'];

    $output .= '<div class="coursetabs-tablist' . $cls . theme_mb2nl_bsfcls(1, 'wrap', '', 'center') . '"' . $style . '>';

    if ($taball) {
        if ($opts['coursecount']) {
            if ($opts['filtertype'] === 'tag') {
                $allcoursecount = theme_mb2nl_get_tags_course_count(0, $opts);
            } else {
                $allcoursecount = theme_mb2nl_get_courses($opts, true);
            }
        }

        $output .= '<button class="coursetabs-catitem position-relative themereset active' .
        theme_mb2nl_bsfcls(2, '', 'center', 'center') . '" data-category="0" aria-controls="' . $opts['uniqid'] .
        '_cc_0" data-uniqid="' . $opts['uniqid'] . '">';
        $output .= '<span class="catname">' . get_string('all', 'local_mb2builder') . '</span>';
        $output .= '<span class="coursecount">(' . $allcoursecount . ')</span>';
        $output .= '</button>'; // ...coursetabs-catitem
    }

    if ($opts['filtertype'] === 'tag') {
        $coursetags = theme_mb2nl_course_tags($opts);
        if (!empty($coursetags)) {
            foreach ($coursetags as $tag) {
                $coursecount = $opts['coursecount'] ? theme_mb2nl_get_tags_course_count($tag->id, $opts) : '';
                $i++;
                $isactive = !$taball && $i == 1 ? ' active' : '';

                $output .= '<button class="coursetabs-catitem position-relative themereset' . $isactive .
                theme_mb2nl_bsfcls(2, '', 'center', 'center') . '" data-category="' .
                $tag->id . '" aria-controls="' . $opts['uniqid'] . '_cc_' . $tag->id . '" data-uniqid="' .
                $opts['uniqid'] . '">';
                $output .= '<span class="catname">' . $tag->rawname . '</span>';
                $output .= '<span class="coursecount">(' . $coursecount . ')</span>';
                $output .= '</button>'; // ...coursetabs-catitem
            }
        }
    } else {
        $opts['withcnt'] = true;
        $opts['notempty'] = true;
        $categories = theme_mb2nl_get_categories($opts);
        if (!empty($categories)) {
            foreach ($categories as $category) {
                $i++;
                $isactive = !$taball && $i == 1 ? ' active' : '';
                $output .= '<button class="coursetabs-catitem position-relative themereset' . $isactive .
                theme_mb2nl_bsfcls(2, '', 'center', 'center') . '" data-category="' .
                $category->id . '" aria-controls="' . $opts['uniqid'] . '_cc_' . $category->id . '" data-uniqid="' .
                $opts['uniqid'] . '">';
                $output .= '<span class="catname">' . theme_mb2nl_format_str($category->name) . '</span>';
                $output .= '<span class="coursecount">(' . $category->coursecount . ')</span>';
                $output .= '</button>'; // ...coursetabs-catitem
            }
        }
    }

    $output .= '</div>'; // ...coursetabs-tablist

    return $output;

}



/**
 *
 * Method to get courses in category tabs
 *
 */
function theme_mb2nl_coursetabs_courses($opts) {

    $output = '';
    $opts['notempty'] = true;
    $items = theme_mb2nl_get_categories($opts); // True means without emepty categories.
    $istag = $opts['filtertype'] === 'tag';
    $i = 0;

    if ($istag) {
        $items = theme_mb2nl_course_tags($opts);
    }

    if (empty($items)) {
        return get_string('nothingtodisplay');
    }

    $preload = theme_mb2nl_preload();
    $taball = $opts['filtertype'] === 'category' ? $opts['taball'] && !$opts['catdesc'] : $opts['taball'];

    if ($taball) {
        $output .= '<div class="coursetabs-content active" id="' . $opts['uniqid'] . '_cc_0">';
        $output .= $preload;
        $output .= '</div>';
    }

    foreach ($items as $item) {
        $i++;
        $activecls = (!$taball && $i == 1) ? ' active' : '';
        $output .= '<div class="coursetabs-content' . $activecls . '" id="' . $opts['uniqid'] . '_cc_' . $item->id  . '">';
        $output .= $preload;
        $output .= '</div>';
    }

    return $output;

}




/**
 *
 * Method to get category element in course tab
 *
 */
function theme_mb2nl_coursetabs_tabcontent($opts) {
    global $PAGE;

    $output = '';

    $courses = theme_mb2nl_get_courses($opts);
    $sliderid = uniqid('swiper_');

    $listcls = '';
    $listcls .= $opts['carousel'] ? ' swiper-wrapper' : '';
    $listcls .= !$opts['carousel'] ? ' theme-boxes theme-col-' . $opts['columns'] : '';
    $listcls .= !$opts['carousel'] ? ' gutter-' . $opts['gutter'] : '';

    $containercls = $opts['carousel'] ? ' swiper' : '';

    $output .= $opts['filtertype'] === 'category' && $opts['catdesc'] ?
    theme_mb2nl_coursetabs_category($opts['categories'][0]) : '';
    $output .= '<div id="' . $sliderid . '" class="mb2-pb-content' . $containercls . '">';
    $output .= theme_mb2nl_shortcodes_swiper_nav($sliderid);
    $output .= '<div class="mb2-pb-content-list' . $listcls . '">';
    $output .= theme_mb2nl_course_list_courses($courses, true, $opts);
    $output .= '</div>'; // ...mb2-pb-content-list
    $output .= theme_mb2nl_shortcodes_swiper_pagenavnav();
    $output .= '</div>'; // ...mb2-pb-content

    return $output;

}




/**
 *
 * Method to get category element in course tab
 *
 */
function theme_mb2nl_coursetabs_category($catid) {
    global $PAGE, $OUTPUT, $CFG;
    require_once($CFG->libdir . '/filelib.php');

    $output = '';
    $category = theme_mb2nl_get_category_record($catid);
    $context = context_coursecat::instance($category->id);

    // Get category description.
    $description = file_rewrite_pluginfile_urls($category->description, 'pluginfile.php', $context->id,
    'coursecat', 'description', null);
    $description = theme_mb2nl_format_txt($description);

    // Category image.
    $catimage = theme_mb2nl_category_image($category->id);
    $courseplaceholder = theme_mb2nl_theme_setting($PAGE, 'courseplaceholder', '', true);
    $plchimage = $courseplaceholder ? $courseplaceholder : $OUTPUT->image_url('course-default', 'theme');
    $imgurl = $catimage ? $catimage : $plchimage;

    $catlink = new moodle_url('/course/index.php', ['categoryid' => $category->id]);

    $output .= '<div class="coursetabs-category">';
    $output .= '<div class="category-desc">';
    $output .= '<h4 class="category-title">' . get_string('categorydesc', 'theme_mb2nl') . '</h4>';
    $output .= $description ? $description : '<p>To add category description and image you have to edit category: <b>' .
    $category->name . '</b>. To set category image just insert an image into category description.</p>';
    $output .= '<div class="category-readmore">';
    $output .= '<a href="' . $catlink . '" class="arrowlink">' . get_string('viewallcourses') . '</a>';
    $output .= '</div>'; // ...category-readmore
    $output .= '</div>'; // ...category-desc
    $output .= '<div class="category-image">';
    $output .= '<div class="catimage" style="background-image:url(\'' . $imgurl . '\');"></div>';
    $output .= '</div>'; // ...category-image
    $output .= '</div>'; // ...coursetabs-category

    return $output;

}





/**
 *
 * Method to get category element in course tab
 *
 */
function theme_mb2nl_category_image($catid, $name=false) {
    global $CFG;

    require_once($CFG->libdir . '/filelib.php');

    $context = context_coursecat::instance($catid);
    $fs = get_file_storage();
    $files = $fs->get_area_files($context->id, 'coursecat', 'description', 0, 'timecreated DESC');

    foreach ($files as $f) {
        if ($f->is_valid_image()) {

            if ($name) {
                return $f->get_filename();
            }

            return moodle_url::make_pluginfile_url($f->get_contextid(), $f->get_component(), $f->get_filearea(), null,
            $f->get_filepath(), $f->get_filename(), false);
        }
    }

    return;
}







/**
 *
 * Method to get category color
 *
 */
function theme_mb2nl_cat_color($catid) {

    if (!count(theme_mb2nl_cat_color_settings())) {
        return [];
    }

    // Get cached colors.
    $cache = cache::make('theme_mb2nl', 'catcolors');
    $cacheid = 'catcolorsupd';

    if (!$cache->get($cacheid)) {
        // Get colors and set it for cache.
        $colors = theme_mb2nl_assign_cat_colors();
        $cache->set($cacheid, $colors);
    }

    // Get cache.
    $colors = $cache->get($cacheid);

    if (isset($colors[$catid])) {
        return $colors[$catid];
    }

    return [];

}



/**
 *
 * Method to get all actegories array
 *
 */
function theme_mb2nl_get_all_categories() {

    global $DB;
    $categories = [];

    // Get cached categories.
    $cache = cache::make('theme_mb2nl', 'category');
    $cacheid = 'allcatlist';

    if (!$cache->get($cacheid)) {
        $recordsql = 'SELECT id, name, path FROM {course_categories}';
        $records = $DB->get_records_sql($recordsql);

        foreach ($records as $cat) {
            $categories[$cat->id] = $cat;
        }

        $cache->set($cacheid, $categories);
    }

    return $cache->get($cacheid);

}




/**
 *
 * Method to assign color to categories
 *
 */
function theme_mb2nl_assign_cat_colors() {

    $cats = [];
    $categories = theme_mb2nl_get_all_categories();
    $colors = theme_mb2nl_cat_color_settings();

    foreach ($categories as $cat) {
        $cat->path = substr(trim($cat->path), 1);
        $path = explode('/', $cat->path);
        $color = '';

        // Get the category path colors.
        foreach ($path as $p) {
            $color .= isset($colors[$p]) ? $colors[$p] . '-' : '';
        }

        // Remove the last "-" character.
        $color = $color ? $color[-1] === '-' ? substr($color, 0, -1) : $color : '';

        // Make an array of the path colors
        // and get the last color.
        $color = explode('-', $color);
        $color = end($color);

        // Assign color to the category.
        $cats[$p] = isset($colors[$cat->path]) ? explode(':', $colors[$cat->path]) : explode(':', $color);

    }

    return $cats;

}






/**
 *
 * Method to set category settings color array
 *
 */
function theme_mb2nl_cat_color_settings() {
    global $PAGE;

    $colorss = theme_mb2nl_theme_setting($PAGE, 'catcolors');
    $colorcats = [];

    // Explode new line.
    $linearr = preg_split('/\s*\R\s*/', trim($colorss));

    foreach ($linearr as $line) {
        $linearr = explode('|', $line);
        $catid = theme_mb2nl_category_idbyname($linearr[0]);

        if (!isset($linearr[1]) || !$catid) {
            continue;
        }

        $colorcats[$catid] = $linearr[1];
    }

    return $colorcats;

}




/**
 *
 * Method to get category color
 *
 */
function theme_mb2nl_cat_color_itemattr($course, $catid = 0) {
    $style = '';

    $iscat = $catid ? $catid : $course->category;
    $colors = theme_mb2nl_cat_color($iscat);

    foreach ($colors as $k => $c) {
        if (!$c) {
            continue;
        }

        $style .= '--mb2-catcolor' . $k . ':' . $c .';';
    }

    return $style;

}






/**
 *
 * Method to get category color
 *
 */
function theme_mb2nl_cat_color_attr($on=false) {
    global $COURSE;

    $curentcat = optional_param('categoryid', 0, PARAM_INT);

    if ((!theme_mb2nl_is_course() && !$curentcat) || !$on) {
        return;
    }

    $style = '';

    $isid = $curentcat ? $curentcat : $COURSE->category;
    $colors = theme_mb2nl_cat_color($isid);

    foreach ($colors as $k => $c) {
        if (!$c) {
            continue;
        }

        $style .= '--mb2-pb-pheadergrad' . ($k + 1) . ':' . $c .';';
        $style .= $k == 0 && !isset($colors[$k + 1]) ? '--mb2-pb-pheadergrad2:' . $c .';' : '';
    }

    return $style;

}
