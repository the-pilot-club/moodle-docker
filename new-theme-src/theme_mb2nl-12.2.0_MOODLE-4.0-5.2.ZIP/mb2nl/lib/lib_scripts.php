<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2026 Mariusz Boloz (lmsstyle.com)
 * @license   PHP and HTML: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later. Other parts: http://themeforest.net/licenses
 *
 */


/**
 *
 * Method to get theme scripts
 *
 */
function theme_mb2nl_scripts() {
    global $PAGE;

    $builderconf = get_config('local_mb2builder');
    $builder = preg_match('@mb2builder-customize@', $PAGE->pagetype);
    $builderedit = preg_match('@mb2builder-edit@', $PAGE->pagetype);

    $themedir = theme_mb2nl_themedir();

    // Main slider script.
    // Load it only if the front page slider is enabled.
    if (theme_mb2nl_is_slider()) {
        $PAGE->requires->jquery();
        $PAGE->requires->js($themedir . '/mb2nl/assets/lightslider/lightslider.js', 0);
        $PAGE->requires->js($themedir . '/mb2nl/assets/lightslider/init.js', 0);
    }

    // Use the 'has_capability' because the spectrum plugin is required not only on the theme settings page.
    // The "$builder" variable is require because content part items may edit none-admin users.
    if (has_capability('moodle/site:config', context_system::instance()) || $builder) {
        $PAGE->requires->css($themedir . '/mb2nl/assets/spectrum/spectrum.css');
    }

    // Load builder style.
    // This is becaus sometimes server blocks local plugin styles.
    if ($builder || $builderedit) {
        if (isset($builderconf->themestyle)) {
            if ($builderconf->themestyle) {
                if ($builderedit) {
                    $PAGE->requires->css($themedir . '/mb2nl/assets/builder/edit_page.css');
                }
                if ($builder) {
                    $PAGE->requires->css($themedir . '/mb2nl/assets/builder/customize.css');
                }
            }
        }
    }

}
