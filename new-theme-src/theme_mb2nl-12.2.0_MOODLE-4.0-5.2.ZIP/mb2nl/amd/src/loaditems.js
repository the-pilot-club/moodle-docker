/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2026 Mariusz Boloz (lmsstyle.com)
 * @license   PHP and HTML: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later. Other parts: http://themeforest.net/licenses
 */ define(["jquery","core/ajax"],function(t,e){"use strict";let n=e=>{for(var n=0;n<e.length;n++){let l=t('[data-i2load="'+e[n]+'"]');l.length&&l.each(function(){i(t(this)).then(e=>{a(e,t(this))}).catch(t=>{require(["core/log"],function(e){e.debug(t)})})})}},i=t=>{let n={i2load:t.attr("data-i2load"),options:t.attr("data-options")};return e.call([{methodname:"theme_mb2nl_load_items",args:n}])[0]};var a=(t,e)=>{let n=e.find(".mb2-pb-content-list"),i=e.find(".swiper");n.html(t.items),i.length?require(["theme_mb2nl/swiperinit"],function(t){let e=t;e.carouselDestroy(i.attr("id")),e.carouselInit(i.attr("id"))}):require(["theme_mb2nl/lazy"],function(t){t.init()})};return{init:n}});