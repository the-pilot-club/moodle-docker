/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2026 Mariusz Boloz (lmsstyle.com)
 * @license   PHP and HTML: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later. Other parts: http://themeforest.net/licenses
 */ define(["jquery"],function(t){"use strict";let e=(e,a=[])=>{let l={};if(t.each(e[0].attributes,function(){if(this.name.startsWith("data-")){let t=this.name.replace("data-","");(0===a.length||a.includes(t))&&(l[t]=this.value)}}),0===a.length)return l;let r={};return a.forEach(t=>{r[t]=l.hasOwnProperty(t)?l[t]:null}),r};return{dataAttribs:e,scrollTtopCls:function(e){var a=t(".theme-scrolltt");e.scrollTop()>500?a.addClass("active"):a.removeClass("active")}}});