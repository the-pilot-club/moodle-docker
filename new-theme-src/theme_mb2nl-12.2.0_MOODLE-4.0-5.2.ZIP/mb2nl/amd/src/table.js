/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2026 Mariusz Boloz (lmsstyle.com)
 * @license   PHP and HTML: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later. Other parts: http://themeforest.net/licenses
 */ define(["jquery"],function(t){return{tableHTML:function(){t("table").wrap('<div class="theme-table-wrap"></div>')},tableClass:function(){t(".theme-table-wrap").each(function(){t(this).find(">table").width()>t(this).width()?t(this).addClass("wider"):t(this).removeClass("wider")})}}});