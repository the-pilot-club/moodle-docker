/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2026 Mariusz Boloz (lmsstyle.com)
 * @license   Commercial https://themeforest.net/licenses
 */ define(["jquery","theme_mb2nl/str"],function(t,e){"use strict";var n=function(e){t(".toggle-content-button").each(function(){var e=t(this),n=e.parent(),o=e.prev(),i=o.find(">div"),s=e.attr("data-height");i.outerHeight()>Math.ceil(2.7*s)?(n.addClass("toggle-content"),o.addClass("content"),o.css("height",s)):(n.removeClass("toggle-content"),o.removeClass("content"),o.attr("style",""))})};return{init:function(e){n(),t(window).on("resize",function(){n()})}}});