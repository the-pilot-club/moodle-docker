/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2026 Mariusz Boloz (lmsstyle.com)
 * @license   PHP and HTML: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later. Other parts: http://themeforest.net/licenses
 */ define(["jquery"],function(a){"use strict";var c=function(a){var c=a.closest(".accimg-nav").find(".accimg-item");c.removeClass("show"),c.find(".accimg-btn").attr("aria-expanded","false"),c.find(".accimg-content").slideUp(250),a.addClass("show"),e(a)},e=function(a){var c=a.closest(".mb2-pb-accordionimg");c.find(".accimg-preview").removeClass("show"),c.find(".accimg-preview-"+a.attr("data-num")).addClass("show"),a.find(".accimg-content").slideDown(250),a.find(".accimg-btn").attr("aria-expanded","true")};return{itemAttrs:e,accItemOpen:c,accItemClose:function(a){a.removeClass("show"),a.find(".accimg-btn").attr("aria-expanded","false"),a.find(".accimg-content").slideUp(250)}}});