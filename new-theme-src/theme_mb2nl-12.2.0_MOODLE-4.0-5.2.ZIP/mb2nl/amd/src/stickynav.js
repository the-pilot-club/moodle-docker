/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2026 Mariusz Boloz (lmsstyle.com)
 * @license   Commercial https://themeforest.net/licenses
 */ define(["jquery"],function(s){"use strict";var t=function(t,e,c){var l=e.length?e.offset().top+70:180;s(window).scrollTop()>l?(e.css("height",c),t.addClass("sticky-el")):(t.removeClass("sticky-el"),e.css("height",0)),s(window).scrollTop()>l+100?t.addClass("sticky-el-jump"):t.removeClass("sticky-el-jump")};return{init:function(e){var c=s(".sticky-replace-el"),l=e.outerHeight(!0);s(window).on("scroll",function(){t(e,c,l)}),setTimeout(function(){t(e,c,l)},10)}}});