<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2026 Mariusz Boloz (lmsstyle.com)
 * @license   PHP and HTML: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later. Other parts: http://themeforest.net/licenses
 */

defined('MOODLE_INTERNAL') || die();


$mb2settings = [
    'id' => 'marquee',
    'subid' => 'marquee_item',
    'title' => get_string('marquee', 'local_mb2builder'),
    'icon' => 'ri-arrow-left-right-line',
    'type' => 'general',
    'tabs' => [
        'general' => get_string('generaltab', 'local_mb2builder'),
        'style' => get_string('styletab', 'local_mb2builder'),
    ],
    'attr' => [
        'type' => [
            'type' => 'buttons',
            'section' => 'general',
            'title' => get_string('type', 'local_mb2builder'),
            'options' => [
                1 => get_string('image', 'local_mb2builder'),
                2 => get_string('text', 'local_mb2builder'),
                3 => get_string('imageandtext', 'local_mb2builder'),
            ],
            'default' => 3,
            'action' => 'class',
            'selector' => '.marquee-warp',
            'class_remove' => 'type1 type2 type3',
            'class_prefix' => 'type',
        ],
        'dir' => [
            'type' => 'buttons',
            'section' => 'general',
            'title' => get_string('adirection', 'local_mb2builder'),
            'options' => [
                'rtl' => 'RTL',
                'ltr' => 'LTR',
            ],
            'default' => 'rtl',
            'action' => 'class',
            'selector' => '.marquee-warp',
            'class_remove' => 'animrtl animltr',
            'class_prefix' => 'anim',
        ],
        'hstop' => [
            'type' => 'yesno',
            'section' => 'general',
            'title' => get_string('hstop', 'local_mb2builder'),
            'options' => [
                1 => get_string('yes', 'local_mb2builder'),
                0 => get_string('no', 'local_mb2builder'),
            ],
            'default' => 0,
            'action' => 'class',
            'selector' => '.marquee-warp',
            'class_remove' => 'hstop0 hstop1',
            'class_prefix' => 'hstop',
        ],
        'duration' => [
            'type' => 'range',
            'section' => 'general',
            'title' => get_string('aduration', 'local_mb2builder'),
            'min' => 1,
            'max' => 100,
            'step' => 1,
            'default' => 45,
            'action' => 'style',
            'changemode' => 'input',
            'selector' => '.marquee-warp',
            'style_properity' => '--mb2pb-mqd',
            'style_suffix' => 's',
        ],
        'gap' => [
            'type' => 'range',
            'section' => 'general',
            'title' => get_string('elpacing', 'local_mb2builder'),
            'min' => 0,
            'max' => 10,
            'step' => 0.01,
            'default' => 1,
            'action' => 'style',
            'changemode' => 'input',
            'selector' => '.marquee-warp',
            'style_properity' => '--mb2pb-mqgap',
            'style_suffix' => 'rem',
        ],
        'imgw' => [
            'type' => 'range',
            'section' => 'general',
            'title' => get_string('imgwidth', 'local_mb2builder'),
            'min' => 50,
            'max' => 2000,
            'step' => 1,
            'default' => 300,
            'action' => 'style',
            'changemode' => 'input',
            'selector' => '.marquee-warp',
            'style_properity' => '--mb2pb-imgw',
        ],
        'imgts' => [
            'type' => 'range',
            'section' => 'general',
            'title' => get_string('imagetextspacing', 'local_mb2builder'),
            'min' => 0,
            'max' => 10,
            'step' => 0.01,
            'default' => 1.2,
            'action' => 'style',
            'changemode' => 'input',
            'selector' => '.marquee-warp',
            'style_properity' => '--mb2pb-imgts',
            'style_suffix' => 'rem',
        ],
        'mt' => [
            'type' => 'range',
            'section' => 'style',
            'title' => get_string('mt', 'local_mb2builder'),
            'min' => 0,
            'max' => 300,
            'default' => 0,
            'action' => 'style',
            'changemode' => 'input',
            'style_properity' => 'margin-top',
        ],
        'mb' => [
            'type' => 'range',
            'section' => 'style',
            'title' => get_string('mb', 'local_mb2builder'),
            'min' => 0,
            'max' => 300,
            'default' => 30,
            'action' => 'style',
            'changemode' => 'input',
            'style_properity' => 'margin-bottom',
        ],
        'custom_class' => [
            'type' => 'text',
            'section' => 'style',
            'title' => get_string('customclasslabel', 'local_mb2builder'),
            'desc' => get_string('customclassdesc', 'local_mb2builder'),
            'default' => '',
        ],
    ],
    'subelement' => [
        'tabs' => [
            'general' => get_string('generaltab', 'local_mb2builder'),
            'accessibility' => get_string('accessibility', 'local_mb2builder'),
        ],
        'attr' => [
            'image' => [
                'type' => 'image',
                'section' => 'general',
                'title' => get_string('image', 'local_mb2builder'),
                'action' => 'image',
                'selector' => '.marquee-img-src',
                'parent' => 1,
                'default' => theme_mb2nl_dummy_image('450x280'),
            ],
            'title' => [
                'type' => 'textarea',
                'section' => 'general',
                'title' => get_string('text', 'local_mb2builder'),
                'action' => 'text',
                'default' => 'Marquee item',
                'selector' => '.marquee-text',
                'parent' => 1,
            ],
            'link' => [
                'type' => 'text',
                'section' => 'general',
                'title' => get_string('link', 'local_mb2builder'),
            ],
            'link_target' => [
                'type' => 'yesno',
                'section' => 'general',
                'title' => get_string('linknewwindow', 'local_mb2builder'),
                'options' => [
                    1 => get_string('yes', 'local_mb2builder'),
                    0 => get_string('no', 'local_mb2builder'),
                ],
                'action' => 'none',
                'default' => 0,
            ],
            'imgalttext' => [
                'type' => 'text',
                'section' => 'accessibility',
                'title' => get_string('alttext', 'local_mb2builder'),
                'action' => 'data',
                'default' => '',
            ],
        ],
    ],
];

define('LOCAL_MB2BUILDER_SETTINGS_MARQUEE', base64_encode(json_encode($mb2settings)));
