<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2026 Mariusz Boloz (lmsstyle.com)
 * @license   PHP and HTML: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later. Other parts: http://themeforest.net/licenses
 */

defined('MOODLE_INTERNAL') || die();

mb2_add_shortcode('mb2pb_marquee', 'mb2pb_shortcode_marquee');
mb2_add_shortcode('mb2pb_marquee_item', 'mb2pb_shortcode_marquee_item');

/**
 *
 * Method to define shortcode
 *
 * @return HTML
 */
function mb2pb_shortcode_marquee($atts, $content = null) {

    $atts2 = [
        'id' => 'marquee',
        'type' => 3, // 1 - image, 2 - text, 3- image and text.
        'dir' => 'rtl',
        'hstop' => 0,
        'gap' => 1,
        'duration' => 45,
        'imgw' => 300,
        'imgts' => 1.2,
        'mt' => 0,
        'mb' => 30,
        'custom_class' => '',
        'template' => '',
    ];

    $a = mb2_shortcode_atts($atts2, $atts);

    $output = '';
    $cls = '';
    $wrapcls = '';
    $wrapstyle = '';
    $styleattr = '';

    $cls .= $a['custom_class'] ? ' ' . $a['custom_class'] : '';
    $cls .= $a['template'] ? ' mb2-pb-template-marquee' : '';

    $styleattr .= ' style="';
    $styleattr .= $a['mt'] ? 'margin-top:' . $a['mt'] . 'px;' : '';
    $styleattr .= $a['mb'] ? 'margin-bottom:' . $a['mb'] . 'px;' : '';
    $styleattr .= '"';

    $wrapcls .= ' anim' . $a['dir'];
    $wrapcls .= ' hstop' . $a['hstop'];
    $wrapcls .= ' type' . $a['type'];

    $wrapstyle .= ' style="';
    $wrapstyle .= '--mb2pb-mqgap:' . $a['gap'] . 'rem;';
    $wrapstyle .= '--mb2pb-mqd:' . $a['duration'] . 's;';
    $wrapstyle .= '--mb2pb-imgw:' . $a['imgw'] . 'px;';
    $wrapstyle .= '--mb2pb-imgts:' . $a['imgts'] . 'rem;';
    $wrapstyle .= '"';

    $content = $content;

    if (!$content) {
        for ($i = 1; $i <= 5; $i++) {
            $content .= '[mb2pb_marquee_item title="Marquee item" image="' . theme_mb2nl_dummy_image('450x280') .
            '" ][/mb2pb_marquee_item]';
        }
    }

    // Get marquee items.
    $regex = '\\[(\\[?)(mb2pb_marquee_item)\\b([^\\]\\/]*(?:\\/(?!\\])[^\\]\\/]*)*?)';
    $regex .= '(?:(\\/)\\]|\\](?:([^\\[]*+(?:\\[(?!\\/\\2\\])[^\\[]*+)*+)\\[\\/\\2\\])?)(\\]?)';
    preg_match_all("/$regex/is", $content, $match);
    $content = $match[0];

    $output .= '<div class="mb2-pb-element mb2-pb-marquee' . $cls . '"' . $styleattr .
    theme_mb2nl_page_builder_el_datatts($atts, $atts2) . '>';
    $output .= '<div class="element-helper"></div>';
    $output .= theme_mb2nl_page_builder_el_actions('element', 'marquee');
    $output .= '<div class="marquee-warp overflow-hidden' . $wrapcls . theme_mb2nl_bsfcls(1, '', 'between', 'center')  . '"' .
    $wrapstyle . '>';

    $output .= '<div class="marquee-group">';
    foreach ($content as $c) {
        $output .= mb2_do_shortcode($c);
    }
    $output .= '</div>';

    $output .= '<div class="marquee-group" aria-hidden="true">';
    foreach ($content as $c) {
        $output .= mb2_do_shortcode($c);
    }
    $output .= '</div>';

    $output .= '</div>';

    $output .= '<div class="mb2-pb-sortable-subelements">';
    $output .= '<a href="#" class="element-items">&#x2715;</a>';

    foreach ($content as $c) {

        // Get attributes of carousel items.
        $attributes = shortcode_parse_atts($c);
        $attr['id'] = 'marquee_item';
        $attr['pbid'] = (isset($attributes['pbid']) && $attributes['pbid']) ? $attributes['pbid'] : '';
        $attr['title'] = (isset($attributes['title']) && $attributes['title']) ? urldecode($attributes['title']) : 'Marquee item';
        $attr['image'] = $attributes['image'];
        $attr['imgalttext'] = (isset($attributes['imgalttext']) && $attributes['imgalttext']) ? urldecode($attributes['imgalttext'])
        : '';

        $output .= '<div class="mb2-pb-subelement mb2-pb-marquee_item" style="background-image:url(\'' . $attr['image'] . '\');"' .
        theme_mb2nl_page_builder_el_datatts($attr, $attr) . '>';
        $output .= theme_mb2nl_page_builder_el_actions('subelement');
        $output .= '<div class="mb2-pb-subelement-inner">';
        $output .= '<div class="sortitem-text">' . $attr['title'] . '</div>';
        $output .= '</div>';
        $output .= '</div>';
    }

    $output .= '</div>';

    $output .= '</div>';

    return $output;

}



/**
 *
 * Method to define shortcode
 *
 * @return HTML
 */
function mb2pb_shortcode_marquee_item($atts, $content = null) {

    $atts2 = [
        'id' => 'marquee_item',
        'pbid' => '', // ...it's require for sorting elements below the marquee items
        'title' => 'Marquee item',
        'image' => theme_mb2nl_dummy_image('450x280'),
        'link' => '',
        'link_target' => 0,
        'imgalttext' => '',
        'template' => '',
    ];

    $output = '';
    $a = mb2_shortcode_atts($atts2, $atts);

    $a['pbid'] = $a['pbid'] ? $a['pbid'] : '';

    $output .= '<div class="marquee-item mb2-pb-parent-item tcenter1' . theme_mb2nl_bsfcls(1, 'column', 'center', 'center') .
    '" data-pbid="' . $a['pbid'] . '">';
    $output .= '<img class="marquee-img-src" src="' . $a['image'] . '" alt="">';
    $output .= '<div class="marquee-text">' . $a['title'] . '</div>';
    $output .= '</div>';

    return $output;

}
