<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 *
 * @package   theme_mb2nl
 * @copyright 2017 - 2026 Mariusz Boloz (lmsstyle.com)
 * @license   PHP and HTML: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later. Other parts: http://themeforest.net/licenses
 */

defined('MOODLE_INTERNAL') || die();

mb2_add_shortcode('marquee', 'mb2_shortcode_marquee');
mb2_add_shortcode('marquee_item', 'mb2_shortcode_marquee_item');

/**
 *
 * Method to define shortcode
 *
 * @return HTML
 */
function mb2_shortcode_marquee($atts, $content = null) {

    global $gl0mqtype;

    $atts2 = [
        'id' => 'marquee',
        'type' => 3, // 1 - image, 2 - text, 3- image and text.
        'dir' => 'rtl',
        'hstop' => 0,
        'gap' => 1,
        'duration' => 45,
        'imgw' => 300,
        'imgts' => 1.2,
        'mt' => 0,
        'mb' => 30,
        'custom_class' => '',
        'template' => '',
    ];

    $a = mb2_shortcode_atts($atts2, $atts);

    $output = '';
    $cls = '';
    $wrapcls = '';
    $wrapstyle = '';
    $styleattr = '';
    $gl0mqtype = $a['type'];

    $cls .= $a['custom_class'] ? ' ' . $a['custom_class'] : '';
    $cls .= $a['template'] ? ' mb2-pb-template-marquee' : '';

    $styleattr .= ' style="';
    $styleattr .= $a['mt'] ? 'margin-top:' . $a['mt'] . 'px;' : '';
    $styleattr .= $a['mb'] ? 'margin-bottom:' . $a['mb'] . 'px;' : '';
    $styleattr .= '"';

    $wrapcls .= ' anim' . $a['dir'];
    $wrapcls .= ' hstop' . $a['hstop'];
    $wrapcls .= ' type' . $a['type'];

    $wrapstyle .= ' style="';
    $wrapstyle .= '--mb2pb-mqgap:' . $a['gap'] . 'rem;';
    $wrapstyle .= '--mb2pb-mqd:' . $a['duration'] . 's;';
    $wrapstyle .= '--mb2pb-imgw:' . $a['imgw'] . 'px;';
    $wrapstyle .= '--mb2pb-imgts:' . $a['imgts'] . 'rem;';
    $wrapstyle .= '"';

    $content = $content;

    // Get marquee items.
    $regex = '\\[(\\[?)(marquee_item)\\b([^\\]\\/]*(?:\\/(?!\\])[^\\]\\/]*)*?)';
    $regex .= '(?:(\\/)\\]|\\](?:([^\\[]*+(?:\\[(?!\\/\\2\\])[^\\[]*+)*+)\\[\\/\\2\\])?)(\\]?)';
    preg_match_all("/$regex/is", $content, $match);
    $content = $match[0];

    $output .= '<div class="mb2-pb-element mb2-pb-marquee' . $cls . '"' . $styleattr . '>';
    $output .= '<div class="marquee-warp overflow-hidden' . $wrapcls . theme_mb2nl_bsfcls(1, '', 'between', 'center')  . '"' .
    $wrapstyle . '>';

    $output .= '<div class="marquee-group">';
    foreach ($content as $c) {
        $output .= mb2_do_shortcode($c);
    }
    $output .= '</div>';

    $output .= '<div class="marquee-group" aria-hidden="true">';
    foreach ($content as $c) {
        $output .= mb2_do_shortcode($c);
    }
    $output .= '</div>';

    $output .= '</div>';
    $output .= '</div>';

    return $output;

}



/**
 *
 * Method to define shortcode
 *
 * @return HTML
 */
function mb2_shortcode_marquee_item($atts, $content = null) {

    global $gl0mqtype;

    $atts2 = [
        'id' => 'marquee_item',
        'pbid' => '', // ...it's require for sorting elements below the marquee items
        'title' => 'Marquee item',
        'image' => theme_mb2nl_dummy_image('450x280'),
        'link' => '',
        'imgalttext' => '',
        'link_target' => 0,
        'template' => '',
    ];

    $output = '';
    $a = mb2_shortcode_atts($atts2, $atts);
    $target = $a['link_target'] ? ' target="_blank"' : '';
    $alttext = $a['imgalttext'] ? $a['imgalttext'] : $a['title'];

    $output .= '<div class="marquee-item mb2-pb-parent-item tcenter1 position-relative' .
    theme_mb2nl_bsfcls(1, 'column', 'center', 'center') . '">';

    if ($gl0mqtype == 1 || $gl0mqtype == 3) {
        $output .= $a['link'] && $gl0mqtype == 1 ? '<a href="' . $a['link'] . '"' . $target . '>' : '';
        $output .= '<img class="marquee-img-src" src="' . $a['image'] . '" alt="' .
        theme_mb2nl_format_str($alttext) . '">';
        $output .= $a['link'] && $gl0mqtype == 1 ? '</a>' : '';
    }

    if ($gl0mqtype == 2 || $gl0mqtype == 3) {
        $output .= '<div class="marquee-text">';
        $output .= $a['link'] ? '<a href="' . $a['link'] . '"' . $target . '>' : '';
        $output .= theme_mb2nl_format_str($a['title']);
        $output .= $a['link'] ? '</a>' : '';
        $output .= '</div>';
    } else if ($gl0mqtype == 1) {
        $output .= '<div class="sr-only">';
        $output .= theme_mb2nl_format_str($a['title']);
        $output .= '</div>';
    }

    $output .= $a['link'] ? '<a class="linkabs" href="' . $a['link'] . '"' . $target . ' tabindex="-1"><span class="sr-only">' .
    $a['title'] . '</span></a>' : '';

    $output .= '</div>';

    return $output;

}
